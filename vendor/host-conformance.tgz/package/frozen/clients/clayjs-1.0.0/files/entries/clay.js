/* clayjs bootstrap. https://clayjs.com */
(function () {
  // Suppress every vendored bundle's window auto-export; the loader assembles
  // window.clay explicitly.
  window.__hyperclayNoAutoExport = true;

  // Merge into any window.clay a satellite already created; never replace it.
  var clay = window.clay = window.clay || {};
  // A second core tag is a no-op: the original boot's `ready` promise survives.
  // A FAILED boot resets the sentinel so a corrected tag can retry; the retry
  // resolves the ORIGINAL `ready` promise via the stashed resolver.
  if (clay.__booted) return;

  function mintReady() {
    clay.ready = new Promise(function (res, rej) {
      clay.__readyResolve = res;
      clay.__readyReject = rej;
    });
    // Nobody may be awaiting a failed boot's promise, and an unhandled rejection
    // in the console is noise on top of the error we already logged.
    clay.ready.catch(function () {});
  }

  if (!clay.ready) mintReady();

  var script = document.currentScript;
  if (!script || !script.src) {
    console.error("clayjs: could not determine my own URL (load me with a classic <script src=...>, not type=\"module\")");
    return;
  }
  clay.__booted = true;

  var url = new URL(script.src, location.href);
  // The query and the fragment come off before the last slash is found. Leaving them
  // on split the base inside them, so clay.js?next=/a/b imported ".../clay.js?next=/a/src/loader.js"
  // and the library never booted.
  var path = url.href.split("#")[0].split("?")[0];
  var base = path.slice(0, path.lastIndexOf("/"));
  // In the npm tarball the entry scripts sit in entries/ while src/ stays beside it
  // at the package root, so a CDN that serves package paths literally (jsDelivr,
  // unpkg) would look for src/ one directory too deep and load nothing. Stepping out
  // of an "entries" segment makes those URLs resolve. clayjs.com never has the
  // segment: build.js flattens entries/ into each version prefix, so this is a no-op
  // there. The question is asked of the pathname, because asking it of the whole URL
  // matched a host merely named "entries" and sent the import to another origin.
  if (url.pathname.slice(0, url.pathname.lastIndexOf("/")).slice(-8) === "/entries") {
    base = base.slice(0, -8);
  }
  import(base + "/src/loader.js")
    .then(function (m) { return m.boot(base, url.searchParams, clay.__readyResolve); })
    .catch(function (err) {
      clay.__booted = false;
      console.error("clayjs failed to load:", err);
      // Settle the promise so `await clay.ready` fails loudly instead of hanging
      // forever with nothing to catch. Then mint a fresh one: a promise settles
      // once, so without this the corrected retry tag would call __readyResolve on
      // an already-rejected promise and every later await would keep throwing even
      // though the retry succeeded.
      var reject = clay.__readyReject;
      mintReady();
      if (reject) reject(err);
    });
})();
