import { ASSERTIONS, TITLES } from './assertions.js';
import { loadFixtures } from './fixtures.js';
import { req } from './http.js';
import { createClient } from './http-client.js';

// The HTTP engine. Points at a base URL and a writable probe document, runs
// H1-H12 in order, and reports one check per assertion. It talks nothing but
// HTTP, so a host written in any language can be checked against itself.

const DEFAULT_DOC = '/_conformance-probe.html';

// A host that is not listening did not fail a check: nothing was asked of it. Only
// these codes mean the request never reached an answer, and only they can turn a
// thrown row into `na`.
const TRANSPORT = new Set(['ECONNREFUSED', 'ECONNRESET', 'EPIPE', 'ETIMEDOUT', 'EHOSTUNREACH', 'ENOTFOUND', 'UND_ERR_SOCKET', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT']);
const isTransportFailure = (error) => TRANSPORT.has(error?.code) || TRANSPORT.has(error?.cause?.code);

function normalizeOnly(only) {
  if (!only) return null;
  return new Set(
    only.map((entry) => entry.trim().replace(/^http\./i, '').toLowerCase()).filter(Boolean),
  );
}

export async function runConformance({
  base,
  doc = DEFAULT_DOC,
  fixturesDir = null,
  only = null,
  profile = null,
  storedRoot = null,
  faultInjector = null,
  headers = {},
  cookies = [],
  tokenFromPage = false,
  token = '',
} = {}) {
  if (!base) throw new Error('runConformance requires a base URL');
  const normalized = base.replace(/\/+$/, '');

  const client = createClient({ base: `${normalized}/`, doc, cookies, headers, tokenFromPage, token });

  const ctx = {
    base: `${normalized}/`,
    doc,
    fixtures: loadFixtures(fixturesDir),
    storedRoot,
    faultInjector,
    headers,
    req,
    client,
  };

  await client.resolveToken();

  const wanted = normalizeOnly(only);
  const checks = [];

  for (const assertion of ASSERTIONS) {
    const shortId = assertion.id;
    const id = `http.${shortId}`;
    if (assertion.profile && assertion.profile !== profile) continue;
    if (wanted && !wanted.has(shortId)) continue;
    const title = TITLES[shortId.toUpperCase()] || assertion.run.name;
    try {
      const result = await assertion.run(ctx);
      checks.push({
        id,
        title: result.title ?? title,
        engine: 'http',
        status: result.status,
        detail: result.detail ?? null,
        blocking: result.blocking ?? false,
      });
    } catch (error) {
      const transport = isTransportFailure(error);
      checks.push({
        id,
        title,
        engine: 'http',
        status: transport ? 'na' : 'fail',
        detail: transport ? `could not reach the host: ${error?.message || error}` : `threw: ${error?.message || error}`,
        blocking: transport,
      });
    }
  }

  return { checks };
}

export { DEFAULT_DOC };
