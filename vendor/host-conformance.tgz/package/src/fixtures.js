import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// The canonical conformance fixtures ship inside this package. In the source
// tree they live one copy up, at the workspace root, so the repo has exactly one
// of them; `npm pack` copies that copy in.

const here = path.dirname(fileURLToPath(import.meta.url));

const CANDIDATES = [
  path.resolve(here, '..', 'fixtures'),
  path.resolve(here, '..', '..', '..', 'fixtures'),
];

export function findFixturesDir(explicit = null) {
  const wanted = explicit || process.env.MAKERCLAY_FIXTURES || null;
  if (wanted) {
    if (!fs.existsSync(path.join(wanted, 'manifest.json'))) {
      throw new Error(`No manifest.json in ${wanted}`);
    }
    return wanted;
  }
  for (const candidate of CANDIDATES) {
    if (fs.existsSync(path.join(candidate, 'manifest.json'))) return candidate;
  }
  return null;
}

export function loadFixtures(dir) {
  const root = findFixturesDir(dir);
  if (!root) return [];
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  return manifest.fixtures
    .filter((entry) => !entry.skipDocument)
    .map((entry) => ({
      name: entry.name,
      summary: entry.description || '',
      requires: entry.requires || [],
      document: fs.readFileSync(path.join(root, entry.name, 'document.html'), 'utf8'),
    }));
}
