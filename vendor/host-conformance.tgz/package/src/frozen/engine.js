import { createHash } from 'node:crypto';
import { readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { getRootAttr, stripHostAttrs } from '../root-attrs.js';
import { browserLaunchOptions, loadChromium } from '../page-engine.js';
import { CLIENT_ROWS } from './client-rows.js';
import { documentEtag, loadExpectations, readStored, selectAnswer, writeStored } from './store.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = path.resolve(HERE, '..', '..');
const CLIENTS_DIR = path.join(PACKAGE_ROOT, 'frozen', 'clients');
const EXPECTATIONS_PATH = path.join(PACKAGE_ROOT, 'frozen', 'expectations.json');
const EXPECTATIONS_FILE = 'frozen/expectations.json';

const CONTENT_TYPES = {
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json',
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.wasm': 'application/wasm',
};

const DOCUMENT = (body) => `<!doctype html>\n<html>\n<head><meta charset="utf-8"><title>conformance</title></head>\n<body>${body}</body>\n</html>\n`;

const shortId = (id) => id.replace(/^frozen\./i, '').toLowerCase();

async function readJson(file) {
  return JSON.parse(await readFile(file, 'utf8'));
}

function parseCookies(pairs, url) {
  const origin = new URL(url);
  return pairs.map((pair) => {
    const eq = pair.indexOf('=');
    if (eq < 1) throw new Error(`--cookie wants name=value, got ${JSON.stringify(pair)}`);
    return { name: pair.slice(0, eq), value: pair.slice(eq + 1), domain: origin.hostname, path: '/' };
  });
}

function clientDocument(client) {
  const rel = client.shell ?? client.historical[0];
  return { rel, file: path.join(CLIENTS_DIR, client.id, rel) };
}

function clientServeName(id) {
  return `_frozen-${id}.html`;
}

function frozenRows(only = null) {
  const wanted = only ? new Set(only.map(shortId)) : null;
  const rows = CLIENT_ROWS.filter((row) => !wanted || wanted.has(shortId(row.id)));
  for (const id of wanted ?? []) {
    if (!CLIENT_ROWS.some((row) => shortId(row.id) === id)) throw new Error(`--only names a frozen check this run does not have: ${id}`);
  }
  return rows;
}

// A host that serves only the documents present when it starts (HTML Clay's fixture, like the
// app, serves what it registered) needs these files placed before it boots. The engine writes the
// same names and bytes again before each row, so placing them first changes no row's result.
export async function placeFrozenDocuments(root, { only = null } = {}) {
  if (!root) throw new Error('placing frozen documents needs --root');
  const placed = [];
  const written = new Set();
  for (const row of frozenRows(only)) {
    const name = clientServeName(row.client);
    if (!written.has(row.client)) {
      written.add(row.client);
      const { file } = clientDocument(await readJson(path.join(CLIENTS_DIR, row.client, 'client.json')));
      await writeStored(root, name, await readFile(file));
    }
    placed.push({ id: row.id, client: row.client, name });
  }
  return placed;
}

async function readHttp(contextRequest) {
  return { status: contextRequest.status(), headers: contextRequest.headers(), text: await contextRequest.text() };
}

async function metaFor(http, servedText, documentUrl) {
  const token = getRootAttr(servedText ?? '', 'savetoken');
  if (token) return http('GET', `/_/meta/${encodeURIComponent(token)}`);
  return http('GET', '/_/meta', { headers: { 'document-url': documentUrl } });
}

async function serveClientFiles(route, client, prefixPath, state) {
  const requested = new URL(route.request().url());
  const rel = decodeURIComponent(requested.pathname.slice(prefixPath.length));
  const file = path.join(CLIENTS_DIR, client.id, 'files', rel);
  let bytes;
  try {
    bytes = await readFile(file);
  } catch {
    state.external.push(route.request().url());
    await route.abort();
    return;
  }
  const digest = createHash('sha256').update(bytes).digest('hex');
  if (client.files[`files/${rel}`] !== digest) {
    state.mismatched.push(`files/${rel}`);
  }
  await route.fulfill({
    status: 200,
    headers: {
      'content-type': CONTENT_TYPES[path.extname(rel)] || 'application/octet-stream',
      'access-control-allow-origin': '*',
    },
    body: bytes,
  });
}

export async function runFrozenEngine({
  url,
  host = null,
  root = '',
  page = '',
  cookies = [],
  only = null,
  token = '',
  insecure = false,
  keep = false,
  expectationsPath = EXPECTATIONS_PATH,
} = {}) {
  if (!url) throw new Error('the frozen engine needs --url');
  if (!root && !page) throw new Error('the frozen engine needs --root (copy the document into a served folder) or --page (the host already serves it)');

  const expectations = loadExpectations(await readJson(expectationsPath), expectationsPath);
  for (const [id, entry] of Object.entries(expectations.rows)) {
    const row = CLIENT_ROWS.find((candidate) => candidate.id === id);
    if (!row) continue;
    selectAnswer(expectations, id, { host: host ?? 'hyperclay-local', answers: row.answers, file: EXPECTATIONS_FILE });
  }

  const rows = frozenRows(only);

  for (const row of rows) {
    selectAnswer(expectations, row.id, { host, answers: row.answers, file: EXPECTATIONS_FILE });
  }

  const chromium = await loadChromium();
  let browser;
  try {
    browser = await chromium.launch(await browserLaunchOptions());
  } catch (error) {
    throw new Error(`the frozen engine could not launch Chromium: ${error?.message || error}`);
  }

  try {
    const context = await browser.newContext(insecure ? { ignoreHTTPSErrors: true } : {});
    if (cookies.length) await context.addCookies(parseCookies(cookies, url));
    const origin = new URL(url).origin;
    const checks = [];

    for (const row of rows) {
      checks.push(await runRow({ row, context, origin, root, page, host, expectations, keep }));
    }
    return { checks };
  } finally {
    await browser.close();
  }
}

async function runRow({ row, context, origin, root, page, host, expectations, keep }) {
  const client = await readJson(path.join(CLIENTS_DIR, row.client, 'client.json'));
  const answer = selectAnswer(expectations, row.id, { host, answers: row.answers, file: EXPECTATIONS_FILE });
  const title = row.title ?? row.id;

  const { file } = clientDocument(client);
  const name = clientServeName(row.client);
  const pageUrl = page ? new URL(page, origin + '/').href : null;
  const serveUrl = root ? new URL(name, origin + '/').href : pageUrl;
  let read;
  let storedName;
  let placed = null;

  if (root) {
    await writeStored(root, name, await readFile(file));
    placed = path.join(root, name);
    storedName = name;
    read = () => readStored(root, storedName);
  } else {
    storedName = page;
    const seeded = await context.request.post(new URL('/_/save', origin + '/').href, {
      headers: {
        'content-type': 'text/html',
        'document-url': pageUrl,
        origin,
        'sec-fetch-site': 'same-origin',
      },
      data: (await readFile(file)).toString('utf8'),
    });
    if (seeded.status() >= 300) throw new Error(`seeding ${page} answered ${seeded.status()}`);
    read = async () => {
      const response = await context.request.get(pageUrl);
      const text = stripHostAttrs(await response.text());
      return { exists: response.status() === 200, text, bytes: Buffer.from(text, 'utf8') };
    };
  }

  const state = { external: [], mismatched: [] };
  const pageHandle = await context.newPage();
  const pageErrors = [];
  pageHandle.on('pageerror', (error) => pageErrors.push(String(error)));

  const saves = [];
  pageHandle.on('request', (request) => {
    if (request.method() !== 'POST' || !request.url().startsWith(origin)) return;
    saves.push({
      request: {
        method: request.method(),
        url: request.url(),
        headers: request.headers(),
        body: request.postData() ?? '',
      },
      response: null,
    });
  });
  // A host that answers its receipt and closes the stream can leave `response.text()` pending
  // forever, so the status and headers are recorded when the event fires and the body only when
  // it settles within a short bound. A row that reads the body says so when it is missing.
  const BODY_WAIT_MS = 2000;
  pageHandle.on('response', (response) => {
    const request = response.request();
    if (request.method() !== 'POST' || !request.url().startsWith(origin)) return;
    const entry = [...saves].reverse().find((candidate) => !candidate.response && candidate.request.url === request.url());
    const recorded = { status: response.status(), headers: response.headers(), body: null };
    if (entry) entry.response = recorded;
    Promise.race([
      response.text().catch(() => null),
      new Promise((resolve) => setTimeout(resolve, BODY_WAIT_MS)),
    ]).then((body) => {
      if (typeof body === 'string') recorded.body = body;
    });
  });

  await context.route('**/*', async (route) => {
    const href = route.request().url();
    if (href.startsWith(origin)) {
      await route.continue();
      return;
    }
    state.external.push(href);
    await route.abort();
  });

  if (client.cdn) {
    const prefixPath = new URL(client.cdn.prefix).pathname;
    await context.route((candidate) => candidate.href.startsWith(client.cdn.prefix), (route) => serveClientFiles(route, client, prefixPath, state));
  }

  const lost = { committed: false, aborted: false, error: null };
  const http = async (method, requestPath, options = {}) => {
    const response = await context.request.fetch(new URL(requestPath, origin + '/').href, {
      method,
      headers: { origin, 'sec-fetch-site': 'same-origin', ...(options.headers || {}) },
      data: options.body,
    });
    return readHttp(response);
  };

  try {
    await pageHandle.goto(serveUrl, { waitUntil: 'domcontentloaded' });
    if (client.drive.kind === 'click') {
      await pageHandle.waitForSelector(client.drive.selector, { timeout: 10000 });
    } else {
      // A frozen client boots from many small files, and on a busy machine that can take
      // longer than a few seconds. An expired wait is reported in the row's own words rather
      // than surfacing later as the drive's TypeError.
      await pageHandle.waitForFunction(() => Boolean(window.hyperclay?.savePageForce || window.clay?.save?.force), null, { timeout: 20000 })
        .catch(() => { pageErrors.push('the client never exposed its save function within 20 seconds'); });
    }
    await pageHandle.waitForTimeout(1000);

    const before = await read();
    const servedResponse = await http('GET', serveUrl);
    const served = { url: serveUrl, text: servedResponse.text };
    const readMeta = (documentUrl = serveUrl) => metaFor(http, served.text, documentUrl);
    const meta = await readMeta();
    let metaJson = null;
    try { metaJson = meta.text ? JSON.parse(meta.text) : null; } catch { metaJson = null; }
    if (!root && page && metaJson?.document?.etag && documentEtag(before.bytes) !== metaJson.document.etag) {
      throw new Error(`/_/meta names stamp ${metaJson.document.etag} but the document read back has ${documentEtag(before.bytes)}`);
    }

    const r = {
      client,
      served,
      before,
      meta: metaJson,
      document: DOCUMENT,
      http,
      read,
      readMeta,
      saves,
      lost,
      marker: row.marker ?? null,
      request: null,
      after: null,
      etagAfter: null,
    };

    if (row.requires?.length) {
      const announced = Array.isArray(metaJson?.extensions) ? metaJson.extensions : [];
      const missing = row.requires.filter((name) => !announced.includes(name));
      if (missing.length) {
        return {
          id: row.id,
          title,
          engine: 'frozen',
          status: 'skip',
          detail: `this host does not announce ${missing.join(', ')}`,
          blocking: false,
          answer,
          client: row.client,
        };
      }
    }

    if (row.intercept === 'lost-response') {
      await pageHandle.route((candidate) => candidate.href.startsWith(origin), async (route) => {
        if (route.request().method() !== 'POST') {
          await route.continue();
          return;
        }
        const original = route.request();
        const forwarded = { ...original.headers(), origin, 'sec-fetch-site': 'same-origin' };
        await route.fetch({ headers: forwarded }).catch((error) => { lost.error = error?.message || String(error); });
        const deadline = Date.now() + 10000;
        while (Date.now() < deadline) {
          const current = await read();
          if (current.exists && documentEtag(current.bytes) !== documentEtag(before.bytes)) {
            lost.committed = true;
            break;
          }
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
        lost.aborted = true;
        await route.abort('connectionreset').catch(() => {});
      });
    }

    if (row.marker) {
      await pageHandle.evaluate((marker) => {
        document.body.insertAdjacentHTML('beforeend', `<p>${marker}</p>`);
      }, row.marker);
    }

    if (row.beforeDrive) await row.beforeDrive(r);

    const drives = row.drives ?? 1;
    r.reads = [];
    for (let index = 0; index < drives; index += 1) {
      if (client.drive.kind === 'click') await pageHandle.click(client.drive.selector);
      else await pageHandle.evaluate(client.drive.expression).catch((error) => { pageErrors.push(String(error)); });
      await pageHandle.waitForTimeout(400);
      if (drives > 1) {
        const deadline = Date.now() + 5000;
        while (Date.now() < deadline) {
          const posts = saves.filter((entry) => entry.request.method === 'POST');
          if (posts[index]?.response) break;
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
        r.reads.push(await read());
      }
    }
    await pageHandle.waitForTimeout(300);

    r.request = saves.find((entry) => entry.request.method === 'POST')?.request ?? null;
    r.after = await read();
    r.etagAfter = r.after.exists ? documentEtag(r.after.bytes) : null;

    await row.answers[answer](r);
    if (state.external.length) {
      throw new Error(`the runtime fetched a URL client.json does not list: ${[...new Set(state.external)].join(', ')}`);
    }
    if (state.mismatched.length) {
      throw new Error(`a served runtime file did not match client.json: ${[...new Set(state.mismatched)].join(', ')}`);
    }
    if (pageErrors.length) {
      throw new Error(`the page reported an error: ${pageErrors.join('; ')}`);
    }

    return {
      id: row.id,
      title,
      engine: 'frozen',
      status: 'pass',
      detail: `${row.client}: ${answer}${r.note ? ` (${r.note})` : ''}${r.protocolOnly ? ' (harness retry is protocol-only)' : ''}`,
      blocking: false,
      answer,
      client: row.client,
    };
  } catch (error) {
    return {
      id: row.id,
      title,
      engine: 'frozen',
      status: 'fail',
      detail: `${row.client}: ${error?.message || error}${pageErrors.length ? ` (${pageErrors.join('; ')})` : ''}`,
      blocking: false,
      answer,
      client: row.client,
    };
  } finally {
    await pageHandle.close().catch(() => {});
    if (placed && !keep) await rm(placed, { force: true });
  }
}
