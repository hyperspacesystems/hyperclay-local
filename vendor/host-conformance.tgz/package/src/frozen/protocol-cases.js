import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { documentEtag } from './store.js';
import expectations from '../../frozen/expectations.json' with { type: 'json' };

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FROZEN_CLIENT = path.join(HERE, '..', '..', 'frozen', 'clients', 'htmlclay-inline-292ac56');
const EXPECTATIONS_FILE = 'frozen/expectations.json';

export function assert(condition, message) {
  if (!condition) throw new Error(message);
}

export function assertEqual(actual, expected, label) {
  if (actual !== expected) {
    throw new Error(`${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

export function htmlDocument(marker, attributes = '') {
  const root = attributes ? `<html ${attributes}>` : '<html>';
  return `<!doctype html>\n${root}\n<head><meta charset="utf-8"><title>${marker}</title></head>\n<body><p>${marker}</p></body>\n</html>\n`;
}

function documentUrl(ctx, rootId, docPath) {
  return `${ctx.rootUrl(rootId)}/${docPath}`;
}

function saveHeaders(ctx, rootId, docPath, extra = {}) {
  return {
    'document-url': documentUrl(ctx, rootId, docPath),
    'content-type': 'text/plain; charset=utf-8',
    ...extra,
  };
}

function saveDocument(ctx, rootId, docPath, body, extra = {}) {
  return ctx.http(rootId, 'POST', '/_/save', {
    headers: saveHeaders(ctx, rootId, docPath, extra),
    body,
  });
}

function bodyJson(response, label) {
  try {
    return response.json();
  } catch (error) {
    throw new Error(`${label}: body is not JSON (${error.message}): ${String(response.text).slice(0, 200)}`);
  }
}

function assertCookieSet(response, name, label) {
  const found = response.setCookie.some((value) => value.startsWith(`${name}=`));
  assert(found, `${label}: ${name} cookie missing from ${JSON.stringify(response.setCookie)}`);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sha256(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

function frozenClientBytes() {
  const client = JSON.parse(readFileSync(path.join(FROZEN_CLIENT, 'client.json'), 'utf8'));
  const rel = 'files/minimal.htmlclay';
  const bytes = readFileSync(path.join(FROZEN_CLIENT, rel));
  assertEqual(sha256(bytes), client.files[rel], 'the frozen client matches its recorded digest');
  return bytes;
}

function servedToken(html) {
  const root = html.match(/<html\b([^>]*)>/i);
  assert(root, 'the served page has an html element');
  for (const name of ['savetoken', 'htmlclaytoken']) {
    const found = root[1].match(new RegExp(`\\b${name}="([^"]*)"`));
    if (found) return found[1];
  }
  return null;
}

function scriptRequest(bytes) {
  const text = bytes.toString('utf8');
  const call = text.match(/fetch\(\s*'([^']*)'\s*\+\s*token\s*,\s*\{([\s\S]*?)\}\s*\)\s*;/);
  assert(call, 'the fixture script builds a fetch call over a token');
  const method = call[2].match(/method:\s*'([^']+)'/);
  assertEqual(method && method[1], 'POST', 'the fixture script posts');
  const contentType = call[2].match(/'Content-Type':\s*'([^']+)'/);
  assert(contentType, 'the fixture script sets a Content-Type');
  return { target: call[1], headers: { 'Content-Type': contentType[1] } };
}

function startSaveProxy(ctx, { rootId, docPath, beforeSha, expectMarker }) {
  return import('node:http').then(({ default: http }) => {
    const target = ctx.rootUrl(rootId);
    const state = { sawCommitted: false, upstreamStatus: null };
    const server = http.createServer(async (req, res) => {
      try {
        const headers = { ...req.headers };
        for (const name of ['host', 'content-length', 'connection', 'transfer-encoding']) delete headers[name];
        const upstream = await fetch(`${target}${req.url}`, {
          method: req.method,
          headers,
          body: req.method === 'GET' || req.method === 'HEAD' ? undefined : req,
          duplex: 'half',
        });
        await upstream.text();
        state.upstreamStatus = upstream.status;
        const deadline = Date.now() + 10000;
        while (Date.now() < deadline) {
          const current = await ctx.read(rootId, docPath);
          if (current.exists && current.sha256 !== beforeSha && current.text.includes(expectMarker)) {
            state.sawCommitted = true;
            break;
          }
          await delay(50);
        }
        req.socket.destroy();
      } catch {
        try { req.socket.destroy(); } catch {}
      }
    });
    return new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(0, '127.0.0.1', () => {
        resolve({
          state,
          url: `http://127.0.0.1:${server.address().port}`,
          close() {
            return new Promise((done) => server.close(done));
          },
        });
      });
    });
  });
}

async function lostSave(ctx, { rootId, docPath, saveId, stamp, body, marker }) {
  const before = await ctx.read(rootId, docPath);
  const proxy = await startSaveProxy(ctx, { rootId, docPath, beforeSha: before.sha256, expectMarker: marker });
  let dropped = false;
  try {
    const response = await fetch(`${proxy.url}/_/save`, {
      method: 'POST',
      headers: saveHeaders(ctx, rootId, docPath, { 'save-id': saveId, 'if-match': stamp }),
      body,
    });
    await response.text();
  } catch {
    dropped = true;
  }
  await proxy.close();
  return { dropped, sawCommitted: proxy.state.sawCommitted, upstreamStatus: proxy.state.upstreamStatus };
}

const caseOf = (id, answers, act) => ({
  id,
  profiles: ['local-full'],
  answers,
  async run(ctx, host = ctx?.host ?? null) {
    const { selectAnswer } = await import('./store.js');
    const answer = selectAnswer(expectations, id, { host, answers, file: EXPECTATIONS_FILE });
    return answers[answer](ctx, await act(ctx));
  },
});

const ALIAS_CLIENT = frozenClientBytes();

export const PROTOCOL_CASES = [
  caseOf('cookie.on-document', {
    'admin-and-logged-in': (ctx, r) => {
      assertEqual(r.res.status, 200, 'document status');
      assertEqual(r.res.header('content-type'), 'text/html; charset=utf-8', 'document content type');
      assertCookieSet(r.res, 'isAdminOfCurrentResource', 'document response');
      assertCookieSet(r.res, 'isLoggedIn', 'document response');
    },
    'admin-only': (ctx, r) => {
      assertEqual(r.res.status, 200, 'document status');
      assertEqual(r.res.header('content-type'), 'text/html; charset=utf-8', 'document content type');
      assertCookieSet(r.res, 'isAdminOfCurrentResource', 'document response');
      assert(!r.res.setCookie.some((value) => value.startsWith('isLoggedIn=')), 'document response sets isLoggedIn');
    },
  }, async (ctx) => {
    const docPath = 'cookie/document.html';
    await ctx.seed('root-a', docPath, htmlDocument('cookie-document'));
    return { res: await ctx.http('root-a', 'GET', `/${docPath}`) };
  }),

  caseOf('cookie.on-non-document', {
    'admin-and-logged-in': (ctx, r) => {
      assertEqual(r.res.status, 200, 'meta status');
      assert(r.res.header('content-type').startsWith('application/json'), 'meta is not a document');
      assertCookieSet(r.res, 'isAdminOfCurrentResource', 'meta response');
      assertCookieSet(r.res, 'isLoggedIn', 'meta response');
    },
    'admin-only': (ctx, r) => {
      assertEqual(r.res.status, 200, 'meta status');
      assert(r.res.header('content-type').startsWith('application/json'), 'meta is not a document');
      assertCookieSet(r.res, 'isAdminOfCurrentResource', 'meta response');
      assert(!r.res.setCookie.some((value) => value.startsWith('isLoggedIn=')), 'meta response sets isLoggedIn');
    },
  }, async (ctx) => {
    const docPath = 'cookie/non-document.html';
    await ctx.seed('root-a', docPath, htmlDocument('cookie-non-document'));
    return {
      res: await ctx.http('root-a', 'GET', '/_/meta', {
        headers: { 'document-url': documentUrl(ctx, 'root-a', docPath) },
      }),
    };
  }),

  caseOf('save.tokenless-document-url', {
    saved: (ctx, r) => {
      assertEqual(r.res.status, 200, 'tokenless save');
      assert(r.state.sha256 !== r.seeded.sha256, 'the tokenless save landed');
      assert(r.state.text.includes('tokenless-saved'), 'the saved bytes are on disk');
      assert(!r.state.text.includes('savetoken'), 'no save token reached the file');
    },
    'token-route': (ctx, r) => {
      assert(r.res.status >= 400, `the tokenless route answered ${r.res.status}`);
      assertEqual(r.state.sha256, r.seeded.sha256, 'the tokenless save did not write');
    },
  }, async (ctx) => {
    const docPath = 'save/tokenless.html';
    const seeded = await ctx.seed('root-a', docPath, htmlDocument('tokenless-seed'));
    const res = await saveDocument(ctx, 'root-a', docPath, htmlDocument('tokenless-saved'));
    return { seeded, res, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('save.legacy-bare-route', {
    saved: (ctx, r) => {
      assertEqual(r.res.status, 200, 'bare route save');
      assert(r.state.sha256 !== r.seeded.sha256, 'the bare route save landed');
      assert(r.state.text.includes('bare-saved'), 'the saved bytes are on disk');
    },
    'no-route': (ctx, r) => {
      assertEqual(r.res.status, 404, 'the bare route');
      assertEqual(r.state.sha256, r.seeded.sha256, 'the refused save left the file unchanged');
    },
  }, async (ctx) => {
    const docPath = 'save/bare-route.html';
    const seeded = await ctx.seed('root-a', docPath, htmlDocument('bare-seed'));
    const res = await ctx.http('root-a', 'POST', '/save', {
      headers: saveHeaders(ctx, 'root-a', docPath),
      body: htmlDocument('bare-saved'),
    });
    return { seeded, res, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('precondition.missing-if-match', {
    saved: (ctx, r) => {
      assertEqual(r.res.status, 200, 'save with no If-Match');
      assert(r.state.sha256 !== r.seeded.sha256, 'the unconditional save landed');
      assert(r.state.text.includes('missing-saved'), 'the saved bytes are on disk');
    },
  }, async (ctx) => {
    const docPath = 'precondition/missing.html';
    const seeded = await ctx.seed('root-a', docPath, htmlDocument('missing-seed'));
    const res = await saveDocument(ctx, 'root-a', docPath, htmlDocument('missing-saved'));
    return { seeded, res, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('precondition.empty-if-match', {
    'refused-412': (ctx, r) => {
      assertEqual(r.res.status, 412, 'save with an empty If-Match');
      const body = bodyJson(r.res, 'save');
      assertEqual(body.code, 'conflict', 'refusal code');
      assertEqual(body.etag, documentEtag(r.state.bytes), 'the refusal names the stored bytes');
      assertEqual(r.state.sha256, r.seeded.sha256, 'the refused save left the file unchanged');
    },
  }, async (ctx) => {
    const docPath = 'precondition/empty.html';
    const seeded = await ctx.seed('root-a', docPath, htmlDocument('empty-seed'));
    const res = await saveDocument(ctx, 'root-a', docPath, htmlDocument('empty-saved'), { 'if-match': '' });
    return { seeded, res, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('precondition.unchanged-save', {
    unchanged: (ctx, r) => {
      assertEqual(r.first.status, 200, 'first save');
      assertEqual(r.stamp, documentEtag(r.afterFirst.text), 'the success stamp describes the stored bytes');
      assertEqual(r.second.status, 200, 'save of identical bytes');
      assertEqual(bodyJson(r.second, 'second save').etag, r.stamp, 'identical bytes keep their stamp');
      assertEqual(r.afterSecond.sha256, r.afterFirst.sha256, 'identical bytes leave the file unchanged');
    },
  }, async (ctx) => {
    const docPath = 'precondition/unchanged.html';
    await ctx.seed('root-a', docPath, htmlDocument('unchanged-seed'));
    const body = htmlDocument('unchanged-body');
    const first = await saveDocument(ctx, 'root-a', docPath, body);
    const stamp = bodyJson(first, 'first save').etag;
    const afterFirst = await ctx.read('root-a', docPath);
    const second = await saveDocument(ctx, 'root-a', docPath, body, { 'if-match': stamp });
    const afterSecond = await ctx.read('root-a', docPath);
    return { first, stamp, afterFirst, second, afterSecond };
  }),

  caseOf('alias.token-attributes', {
    stripped: (ctx, r) => {
      assertEqual(r.res.status, 200, 'save of a token-attribute document');
      assert(r.state.text.includes('alias-saved'), 'the save landed');
      assert(!r.state.text.includes('htmlclaytoken'), 'the legacy token was stripped');
      assert(!r.state.text.includes('stale-credential'), 'no credential reached the file');
      assert(r.state.text.includes('htmlclayid="doc-identity-1"'), 'the document identity was kept');
    },
  }, async (ctx) => {
    const docPath = 'alias/token-attributes.html';
    await ctx.seed(
      'root-a',
      docPath,
      htmlDocument('alias-seed', 'htmlclaytoken="stale-credential" htmlclayid="doc-identity-1"'),
    );
    const res = await saveDocument(
      ctx,
      'root-a',
      docPath,
      htmlDocument('alias-saved', 'htmlclaytoken="stale-credential" htmlclayid="doc-identity-1"'),
    );
    return { res, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('receipt.lost-response', {
    receipted: (ctx, r) => {
      assertEqual(r.lost.dropped, true, 'the proxy dropped the save response');
      assertEqual(r.lost.sawCommitted, true, 'the proxy observed the committed bytes on disk before dropping');
      assertEqual(r.meta.status, 200, 'meta status');
      assertEqual(r.document.saveId, r.saveId, 'meta reports the lost save as the one that landed');
      assert(r.document.etag !== r.stamp, 'the lost save moved the stamp');
      assertEqual(r.retry.status, 412, 'the retry under the original stamp is refused');
      const retryBody = bodyJson(r.retry, 'retry');
      assertEqual(retryBody.code, 'conflict', 'retry code');
      assertEqual(retryBody.saveId, r.saveId, "the refusal names the retry's own save id");
      assertEqual(retryBody.etag, r.document.etag, 'the refusal names the current stamp');
      assert(r.state.text.includes('receipt-lost-response-body'), 'the file still holds the lost save');
    },
  }, async (ctx) => {
    const docPath = 'receipt/lost-response.html';
    await ctx.seed('root-a', docPath, htmlDocument('receipt-seed'));
    const base = await saveDocument(ctx, 'root-a', docPath, htmlDocument('receipt-start'));
    assertEqual(base.status, 200, 'baseline save');
    const stamp = bodyJson(base, 'baseline save').etag;
    const saveId = 'lost-response-save-0001';
    const body = htmlDocument('receipt-lost-response-body');
    const lost = await lostSave(ctx, { rootId: 'root-a', docPath, saveId, stamp, body, marker: 'receipt-lost-response-body' });
    const meta = await ctx.http('root-a', 'GET', '/_/meta', {
      headers: { 'document-url': documentUrl(ctx, 'root-a', docPath) },
    });
    const document = bodyJson(meta, 'meta').document;
    const retry = await saveDocument(ctx, 'root-a', docPath, body, { 'save-id': saveId, 'if-match': stamp });
    return { saveId, stamp, lost, meta, document, retry, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('receipt.foreign-save-not-overwritten', {
    'not-overwritten': (ctx, r) => {
      assertEqual(r.lost.dropped, true, 'the proxy dropped the save response');
      assertEqual(r.lost.sawCommitted, true, 'the proxy observed the committed bytes on disk before dropping');
      assertEqual(r.afterLost.saveId, r.saveId, 'meta reports the lost save');
      assertEqual(r.foreign.status, 200, 'a different save lands');
      assert(r.foreignStamp !== r.afterLost.etag, 'the foreign save moved the stamp');
      assertEqual(r.retry.status, 412, 'the retry under the original stamp is refused');
      const retryBody = bodyJson(r.retry, 'retry');
      assertEqual(retryBody.code, 'conflict', 'retry code');
      assert(retryBody.saveId === undefined, 'the receipt no longer names the lost save');
      assertEqual(retryBody.etag, r.foreignStamp, "the refusal names the foreign save's stamp");
      assert(r.state.text.includes('foreign-other-save'), 'the file holds the foreign save');
      assert(!r.state.text.includes('foreign-lost-body'), 'the retry did not overwrite it');
    },
  }, async (ctx) => {
    const docPath = 'receipt/foreign-save.html';
    await ctx.seed('root-a', docPath, htmlDocument('foreign-seed'));
    const base = await saveDocument(ctx, 'root-a', docPath, htmlDocument('foreign-start'));
    assertEqual(base.status, 200, 'baseline save');
    const stamp = bodyJson(base, 'baseline save').etag;
    const saveId = 'foreign-save-lost-0001';
    const lostBody = htmlDocument('foreign-lost-body');
    const lost = await lostSave(ctx, { rootId: 'root-a', docPath, saveId, stamp, body: lostBody, marker: 'foreign-lost-body' });
    const meta = await ctx.http('root-a', 'GET', '/_/meta', {
      headers: { 'document-url': documentUrl(ctx, 'root-a', docPath) },
    });
    const afterLost = bodyJson(meta, 'meta').document;
    const foreign = await saveDocument(ctx, 'root-a', docPath, htmlDocument('foreign-other-save'), {
      'if-match': afterLost.etag,
    });
    const foreignStamp = bodyJson(foreign, 'foreign save').etag;
    const retry = await saveDocument(ctx, 'root-a', docPath, lostBody, { 'save-id': saveId, 'if-match': stamp });
    return { saveId, lost, afterLost, foreign, foreignStamp, retry, state: await ctx.read('root-a', docPath) };
  }),

  caseOf('alias.frozen-client', {
    saved: (ctx, r) => {
      assert(r.res.status >= 200 && r.res.status < 300, `the token lane answered ${r.res.status}`);
      assert(r.after.sha256 !== r.before.sha256, 'the frozen client wrote the document');
    },
    'no-token-lane': (ctx, r) => {
      assertEqual(r.res.status, 404, `the token lane ${r.target}${r.token}`);
      assertEqual(r.after.sha256, r.before.sha256, 'the frozen client left the document bytes unchanged');
      assertEqual(JSON.stringify(r.versionsAfter), JSON.stringify(r.versionsBefore), 'the versions folder is unchanged');
    },
  }, async (ctx) => {
    const docPath = 'alias/frozen-client.html';
    await ctx.seed('root-a', docPath, ALIAS_CLIENT);
    const before = await ctx.read('root-a', docPath);
    const versionsPath = `.hyperclay/versions/${docPath.replace(/\.html$/, '')}`;
    const versionsBefore = ctx.versions ? await ctx.versions(ctx, versionsPath) : null;
    const served = await ctx.http('root-a', 'GET', `/${docPath}`);
    assertEqual(served.status, 200, 'the served page');
    const injected = servedToken(served.text);
    const token = injected ?? 'no-token';
    const request = scriptRequest(ALIAS_CLIENT);
    const res = await ctx.http('root-a', 'POST', `${request.target}${token}`, {
      headers: request.headers,
      body: `<!DOCTYPE html>\n${served.text}`,
    });
    const after = await ctx.read('root-a', docPath);
    const versionsAfter = ctx.versions ? await ctx.versions(ctx, versionsPath) : null;
    return { target: request.target, token, res, before, after, versionsBefore, versionsAfter };
  }),
];
