import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

import { stripHostAttrs } from '../root-attrs.js';

export function documentEtag(bytes) {
  const buffer = Buffer.isBuffer(bytes) ? bytes : Buffer.from(String(bytes ?? ''), 'utf8');
  return createHash('sha256').update(buffer).digest('hex').slice(0, 16);
}

export async function readStored(root, name) {
  try {
    const bytes = await readFile(path.join(root, name));
    return { exists: true, bytes, text: bytes.toString('utf8') };
  } catch (error) {
    if (error.code === 'ENOENT') return { exists: false, bytes: null, text: null };
    throw error;
  }
}

export async function writeStored(root, name, contents) {
  const file = path.join(root, name);
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, contents);
  return file;
}

export function stripped(bytes) {
  return stripHostAttrs(bytes.toString('utf8'));
}

export function loadExpectations(parsed, file = 'expectations.json') {
  if (!parsed || parsed.schema !== 1 || typeof parsed.rows !== 'object' || parsed.rows === null) {
    throw new Error(`${file} is not a schema 1 expectations document`);
  }
  return parsed;
}

export function selectAnswer(expectations, id, { host = null, answers, file = 'expectations.json' } = {}) {
  const entry = expectations.rows[id];
  if (!entry) throw new Error(`${file} says nothing about ${id}`);
  const hosts = entry.hosts ?? {};
  const differs = Object.values(hosts).some((value) => value?.answer !== entry.default);
  let selected = entry.default;
  if (host) {
    if (hosts[host]) selected = hosts[host].answer;
    else if (differs) throw new Error(`${file} names no answer for host ${host} on ${id}`);
  } else if (differs) {
    throw new Error(`${id} answers differently per host; pass --host to select one`);
  }
  if (!answers || !Object.hasOwn(answers, selected)) {
    throw new Error(`${file} names the unknown answer ${JSON.stringify(selected)} for ${id}`);
  }
  return selected;
}
