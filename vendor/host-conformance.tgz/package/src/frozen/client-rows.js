import { getRootAttr } from '../root-attrs.js';
import { assert, assertEqual } from './protocol-cases.js';

const pathOf = (request) => new URL(request.url).pathname;

const saveRequests = (r) => r.saves.filter((entry) => entry.request?.method === 'POST');

function assertFullDocument(entry, label) {
  assert(entry.request, `${label}: no save request was captured`);
  assertEqual(entry.request.method, 'POST', `${label}: the save method`);
  assert(typeof entry.request.body === 'string' && entry.request.body.length > 0, `${label}: the save body is empty`);
  assert(/<html[\s>]/i.test(entry.request.body), `${label}: the save body is not a document`);
}

function assertNoWrite(r, label) {
  assert(r.before.exists, `${label}: the document was not on disk before the save`);
  assert(r.after.exists, `${label}: the document is missing after the refused save`);
  assert(r.after.bytes.equals(r.before.bytes), `${label}: the refused save changed the stored bytes`);
}

function assertNoRoute(entry, r, label) {
  assert(entry.response, `${label}: no save response was captured`);
  const status = entry.response.status;
  assert(status === 404 || status === 405, `${label}: the host answered ${status}, not 404 or 405`);
  r.note = `${label} answered ${status}`;
}

const assertLanded = (r, label) => {
  assert(!r.before?.text?.includes(r.marker), `${label}: the marker was on disk before the save`);
  assert(r.after?.exists && r.after.text.includes(r.marker), `${label}: the saved bytes did not reach the store`);
};

const saveRoute = (r) => {
  const token = getRootAttr(r.served.text ?? '', 'savetoken');
  return token ? `/_/save/${encodeURIComponent(token)}` : '/_/save';
};

const anySave = (r) => {
  const saves = saveRequests(r);
  assert(saves.length > 0, 'the drive produced no save request');
  return saves;
};

export const CLIENT_ROWS = [
  {
    id: 'frozen.inline-token-save',
    client: 'htmlclay-inline-292ac56',
    marker: 'frozen-inline-token-save-body',
    answers: {
      saved: (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'inline-token save');
        assert(/^\/_\/save\/[^/]+$/.test(pathOf(entry.request)), `inline-token save: unexpected route ${pathOf(entry.request)}`);
        assert(entry.response.status >= 200 && entry.response.status < 300, `inline-token save answered ${entry.response.status}`);
        assertLanded(r, 'inline-token save');
      },
      'no-token-lane': (r) => {
        const entry = anySave(r)[0];
        assert(/^\/_\/save\/(null|undefined)$/.test(pathOf(entry.request)), `no-token-lane: unexpected route ${pathOf(entry.request)}`);
        assertEqual(entry.response.status, 404, 'no-token-lane save');
        assertNoWrite(r, 'no-token-lane');
      },
    },
  },
  {
    id: 'frozen.welcome-alias-save',
    client: 'htmlclay-welcome-1.8.0',
    marker: 'frozen-welcome-alias-save-body',
    answers: {
      saved: (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'welcome alias save');
        assert(/^\/_\/save\/[^/]+$/.test(pathOf(entry.request)), `welcome alias save: unexpected route ${pathOf(entry.request)}`);
        assert(entry.response.status >= 200 && entry.response.status < 300, `welcome alias save answered ${entry.response.status}`);
        assertLanded(r, 'welcome alias save');
      },
      'no-token-lane': (r) => {
        const saves = saveRequests(r);
        if (saves.length) {
          const entry = saves[0];
          assert(/^\/_\/save\/(null|undefined)$/.test(pathOf(entry.request)), `no-token-lane: unexpected route ${pathOf(entry.request)}`);
          assertEqual(entry.response.status, 404, 'no-token-lane save');
        }
        assertNoWrite(r, 'no-token-lane');
      },
    },
  },
  {
    id: 'frozen.oldest-cookie-lane',
    client: 'hyperclayjs-1.24.0',
    answers: {
      'broken-today': (r) => {
        const entry = anySave(r)[0];
        assertEqual(pathOf(entry.request), '/save/null', 'the oldest cookie lane route');
        assertNoRoute(entry, r, 'the oldest cookie lane');
        assertNoWrite(r, 'broken-today');
      },
    },
  },
  {
    id: 'frozen.bare-save-route',
    client: 'hyperclayjs-1.30.0',
    marker: 'frozen-bare-save-route-body',
    answers: {
      saved: (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'bare save');
        assertEqual(pathOf(entry.request), '/save', 'the bare save route');
        assert(entry.response.status >= 200 && entry.response.status < 300, `bare save answered ${entry.response.status}`);
        assertLanded(r, 'bare save');
      },
      'refused-json': (r) => {
        const entry = anySave(r)[0];
        assertEqual(pathOf(entry.request), '/save', 'the bare save route');
        assertEqual(entry.request.headers['content-type'], 'application/json', 'the recorded runtime sends the JSON envelope on localhost');
        assertEqual(entry.response.status, 415, 'the JSON envelope status');
        assertNoWrite(r, 'refused-json');
      },
      'no-route': (r) => {
        const entry = anySave(r)[0];
        assertEqual(pathOf(entry.request), '/save', 'the bare save route');
        assertNoRoute(entry, r, 'the bare save route');
        assertNoWrite(r, 'no-route');
      },
    },
  },
  {
    id: 'frozen.marked-save-route',
    client: 'hyperclayjs-1.39.1',
    marker: 'frozen-marked-save-route-body',
    answers: {
      saved: (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'marked save');
        assert(/^\/_\/save(?:\/[^/]+)?$/.test(pathOf(entry.request)), `marked save: unexpected route ${pathOf(entry.request)}`);
        assert(entry.request.headers['document-url'], 'marked save sends Document-URL');
        assert(entry.response.status >= 200 && entry.response.status < 300, `marked save answered ${entry.response.status}`);
        assertLanded(r, 'marked save');
      },
      'token-route': (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'marked save');
        assert(/^\/_\/save\/[^/]+$/.test(pathOf(entry.request)), `marked save: unexpected route ${pathOf(entry.request)}`);
        assert(entry.response.status >= 200 && entry.response.status < 300, `marked save answered ${entry.response.status}`);
        assertLanded(r, 'marked save');
      },
    },
  },
  {
    id: 'frozen.cookie-lane-save',
    client: 'hyperclayjs-1.37.5',
    marker: 'frozen-cookie-lane-save-body',
    answers: {
      saved: (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'cookie-lane save');
        assertEqual(pathOf(entry.request), '/_/save', 'the cookie-lane save route');
        assert(entry.request.headers['page-url'], 'cookie-lane save sends Page-URL');
        assert(!entry.request.headers['document-url'], 'cookie-lane save sends no Document-URL');
        assert(entry.response.status >= 200 && entry.response.status < 300, `cookie-lane save answered ${entry.response.status}`);
        assertLanded(r, 'cookie-lane save');
      },
      'token-route': (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'cookie-lane save');
        assert(/^\/_\/save\/[^/]+$/.test(pathOf(entry.request)), `cookie-lane save: unexpected route ${pathOf(entry.request)}`);
        assert(entry.request.headers['page-url'], 'cookie-lane save sends Page-URL');
        assert(!entry.request.headers['document-url'], 'cookie-lane save sends no Document-URL');
        assert(entry.response.status >= 200 && entry.response.status < 300, `cookie-lane save answered ${entry.response.status}`);
        assertLanded(r, 'cookie-lane save');
      },
    },
  },
  {
    id: 'frozen.unchanged-save',
    client: 'clayjs-1.0.0',
    requires: ['conditional'],
    drives: 2,
    answers: {
      unchanged: (r) => {
        const saves = saveRequests(r);
        assertEqual(saves.length, 2, 'the two drives produced two saves');
        for (const entry of saves) {
          assertFullDocument(entry, 'unchanged save');
          assert(entry.response.status >= 200 && entry.response.status < 300, `unchanged save answered ${entry.response.status}`);
        }
        const first = saves[0].response.body;
        const second = saves[1].response.body;
        assert(first && second, 'both saves answered a JSON receipt');
        let firstBody;
        let secondBody;
        try {
          firstBody = JSON.parse(first);
          secondBody = JSON.parse(second);
        } catch {
          throw new Error('unchanged save: a receipt was not JSON');
        }
        assertEqual(secondBody.etag, firstBody.etag, 'identical bytes keep their stamp');
        assert(typeof firstBody.etag === 'string' && firstBody.etag.length > 0, 'unchanged save: the receipt names no stamp');
        assertEqual(r.reads?.length, 2, 'unchanged save: the store was read after each save');
        assert(r.reads[0].exists && r.reads[1].exists, 'unchanged save: the document is not on disk after both saves');
        assert(Buffer.compare(Buffer.from(r.reads[0].bytes), Buffer.from(r.reads[1].bytes)) === 0, 'identical bytes changed the stored file');
      },
    },
  },
  {
    id: 'frozen.lost-response',
    client: 'clayjs-1.10.0',
    requires: ['receipts'],
    intercept: 'lost-response',
    marker: 'frozen-lost-response-body',
    answers: {
      receipted: async (r) => {
        assert(r.request, 'the drive produced no save request');
        assertEqual(r.request.method, 'POST', 'the lost save method');
        assert(r.request.headers['if-match'], 'the recorded client sent no If-Match');
        assert(r.request.headers['save-id'], 'the recorded client sent no Save-ID');
        assertEqual(r.lost.committed, true, 'the new bytes reached the store before the response was dropped');
        assertEqual(r.lost.aborted, true, 'the save response was not dropped');

        const meta = await r.readMeta(r.request.headers['document-url']);
        assertEqual(meta.status, 200, 'meta status');
        const document = JSON.parse(meta.text).document;
        assertEqual(document.saveId, r.request.headers['save-id'], 'meta reports the lost save as the one that landed');
        assert(document.etag !== r.request.headers['if-match'], 'the lost save moved the stamp');

        const replay = await r.http('POST', pathOf(r.request), {
          headers: {
            'document-url': r.request.headers['document-url'],
            'content-type': r.request.headers['content-type'] || 'text/html',
            'save-id': r.request.headers['save-id'],
            'if-match': r.request.headers['if-match'],
          },
          body: r.request.body,
        });
        r.protocolOnly = true;
        assertEqual(replay.status, 412, 'the replay under the original stamp is refused');
        const replayBody = JSON.parse(replay.text);
        assertEqual(replayBody.code, 'conflict', 'replay code');
        assertEqual(replayBody.etag, document.etag, 'the refusal names the current stamp');
        assertEqual(r.etagAfter, document.etag, 'the stored stamp describes the stored bytes');
        assert(r.after.text.includes(r.marker), 'the lost save left its bytes on disk');
      },
    },
  },
  {
    id: 'frozen.foreign-save-not-overwritten',
    client: 'clayjs-1.10.0',
    requires: ['receipts'],
    marker: 'frozen-foreign-client-body',
    beforeDrive: async (r) => {
      const foreign = await r.http('POST', saveRoute(r), {
        headers: {
          'document-url': r.served.url,
          'content-type': 'text/html',
          'if-match': r.meta.document.etag,
        },
        body: r.document('<p>foreign-other-save</p>'),
      });
      assertEqual(foreign.status, 200, 'the other writer save');
      r.foreignEtag = JSON.parse(foreign.text).etag;
      r.foreignText = r.document('<p>foreign-other-save</p>');
    },
    answers: {
      'not-overwritten': (r) => {
        const entry = anySave(r)[0];
        assertFullDocument(entry, 'foreign save');
        assertEqual(entry.response.status, 412, 'the recorded client save under its old stamp');
        assert(typeof entry.response.body === 'string' && entry.response.body.length > 0, 'the 412 carried no receipt body');
        assertEqual(JSON.parse(entry.response.body).code, 'conflict', 'the refusal code');
        assert(entry.request.body.includes(r.marker), 'the recorded client sent its own bytes');
        assert(r.after.text.includes('foreign-other-save'), 'the other writer bytes survive');
        assertEqual(r.after.text, r.foreignText, 'the refused save did not overwrite the other writer');
      },
    },
  },
];
