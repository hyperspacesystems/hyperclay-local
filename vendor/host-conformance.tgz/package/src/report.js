// The report is the contract with hypersave: one JSON document per run, written
// whether the run passed or failed, so a caller can read the failed rows rather
// than scrape the console. `schema` moves whenever the shape changes
// incompatibly.

// A save token is a credential: it is all a caller needs to write the document.
// Details quote routes and served markup, so a token reaches a report by accident,
// and a report is a file people paste. Redacting at the boundary keeps every
// producer of a detail from having to remember.
const KNOWN_TOKEN_ROUTE = /\/_\/(meta|save|data-loss|blockeditor-state)\/[^\s"'<>)]+/g;
const TOKEN_ROUTE = /\/_\/[A-Za-z0-9-]+\/[A-Za-z0-9_-]{16,}/g;
const TOKEN_ATTR = /\b(savetoken|htmlclaytoken)(\s*=\s*)(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;

export function redactTokens(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(KNOWN_TOKEN_ROUTE, (route) => route.replace(/\/[^/]+$/, '/<token>'))
    .replace(TOKEN_ROUTE, (route) => route.replace(/\/[^/]+$/, '/<token>'))
    .replace(TOKEN_ATTR, (_, name, eq) => `${name}${eq}"<token>"`);
}

export function buildReport({ host, url, startedAt, checks, version }) {
  const count = (status) => checks.filter((c) => c.status === status).length;
  const unanswered = checks.filter((c) => c.status === 'na' && c.blocking).length;
  const summary = {
    pass: count('pass'),
    fail: count('fail'),
    skip: count('skip') + checks.filter((c) => c.status === 'na' && !c.blocking).length,
    waived: count('waived'),
    unused: count('waiver-unused'),
    unanswered,
  };
  return {
    schema: 1,
    package: '@panphora/host-conformance',
    version,
    host: host ?? null,
    url,
    startedAt,
    finishedAt: new Date().toISOString(),
    checks: checks.map((check) => (typeof check.detail === 'string' ? { ...check, detail: redactTokens(check.detail) } : check)),
    summary,
    ok: summary.fail === 0 && unanswered === 0,
  };
}

// Three codes and no others: 0 nothing failed, 1 something failed, 3 the run
// could not answer. 3 never reads as a verdict, because a check nobody could
// run is not a check that passed.
export function exitCode(report) {
  if (report.summary.unanswered > 0) return 3;
  return report.ok ? 0 : 1;
}
