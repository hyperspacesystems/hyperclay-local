import { readFile } from 'node:fs/promises';

// A waiver is a dated admission, not a permanent silence: `reason` says why the
// host cannot pass yet and `until` bounds how long the file can hide a
// regression. The check still runs, and its own answer is kept in `rawStatus`.
//
// The file lives at a host repo's root, so it is a tested input that appears in
// review rather than a flag somebody types.

export class WaiverFileError extends Error {}

export async function loadWaivers(file, { required = false } = {}) {
  let text;
  try {
    text = await readFile(file, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT' && !required) return [];
    throw new WaiverFileError(`cannot read ${file}: ${error.message}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (error) {
    throw new WaiverFileError(`${file} is not JSON: ${error.message}`);
  }
  if (parsed.version !== 1 || !Array.isArray(parsed.waivers)) {
    throw new WaiverFileError(`${file} needs {"version":1,"waivers":[...]}`);
  }
  const seen = new Set();
  for (const w of parsed.waivers) {
    if (typeof w.check !== 'string' || !w.check) throw new WaiverFileError(`${file}: a waiver has no check id`);
    if (typeof w.reason !== 'string' || !w.reason.trim()) throw new WaiverFileError(`${file}: ${w.check} has no reason`);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(w.until ?? '') || Number.isNaN(Date.parse(w.until))) {
      throw new WaiverFileError(`${file}: ${w.check} needs "until" as YYYY-MM-DD`);
    }
    if (seen.has(w.check)) throw new WaiverFileError(`${file}: ${w.check} is listed twice`);
    seen.add(w.check);
  }
  return parsed.waivers;
}

export function applyWaivers(checks, waivers, { today = new Date().toISOString().slice(0, 10), known = null } = {}) {
  const byId = new Map(waivers.map((w) => [w.check, w]));
  const ran = new Set(checks.map((c) => c.id));
  const unknown = waivers.filter((w) => !ran.has(w.check) && !(known && known.has(w.check))).map((w) => w.check);
  if (unknown.length) throw new WaiverFileError(`waivers name checks that did not run: ${unknown.join(', ')}`);
  return checks.map((input) => {
    const check = { ...input, rawStatus: input.status };
    const waiver = byId.get(check.id);
    if (!waiver) return { ...check, waiver: null };
    if (check.status === 'pass') {
      return { ...check, status: 'waiver-unused', detail: 'this check now passes, so remove its waiver', waiver };
    }
    if (check.status !== 'fail') return { ...check, waiver };
    if (waiver.until < today) {
      return { ...check, detail: `waiver expired on ${waiver.until}: ${check.detail}`, waiver };
    }
    return { ...check, status: 'waived', waiver };
  });
}
