// A minimal root-tag reader for the runner. The core has a fuller one, but a
// conformance runner that any host can point at itself must not depend on the
// implementation it is testing.

const HOST_ATTRS = ['savetoken', 'htmlclaytoken', 'documentid', 'htmlclayid', 'documentetag', 'sitevisibility'];

export function rootTagSpan(html) {
  const match = /<html(\s[^>]*)?>/i.exec(html);
  if (!match) return null;
  return { start: match.index, end: match.index + match[0].length, attrs: match[1] || '' };
}

export function getRootAttr(html, name) {
  const span = rootTagSpan(html);
  if (!span) return null;
  const pattern = new RegExp(`(?:^|\\s)${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i');
  const hit = pattern.exec(span.attrs);
  if (!hit) return null;
  return hit[2] ?? hit[3] ?? hit[4] ?? '';
}

export function stripHostAttrs(html, names = HOST_ATTRS) {
  const span = rootTagSpan(html);
  if (!span) return html;
  let attrs = span.attrs;
  for (const name of names) {
    attrs = attrs.replace(
      new RegExp(`\\s${name}\\s*=\\s*(?:"[^"]*"|'[^']*'|[^\\s>]+)`, 'gi'),
      '',
    );
  }
  const tag = `<html${attrs}>`;
  return html.slice(0, span.start) + tag + html.slice(span.end);
}

export { HOST_ATTRS };
