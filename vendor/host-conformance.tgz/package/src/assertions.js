import { randomUUID } from 'node:crypto';
import { readdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';

import { dataGuardNotified, dataGuardRefusals, dataGuardRestore } from './data-guard-check.js';
import { sha256 } from './http.js';
import { getRootAttr, rootTagSpan, stripHostAttrs } from './root-attrs.js';

// H1-H12: the assertions any Malleable Document host must pass, in any
// language, run over real HTTP against a running server.
//
// Each returns { id, title, status: 'pass'|'fail'|'skip', detail }.

const DOC = (body = '<p>conformance</p>') =>
  `<!DOCTYPE html>\n<html lang="en">\n<head><meta charset="utf-8"><title>Conformance</title></head>\n<body>${body}</body>\n</html>\n`;

const pass = (id, title, detail = '') => ({ id, title, status: 'pass', detail });
const fail = (id, title, detail) => ({ id, title, status: 'fail', detail });
const skip = (id, title, detail) => ({ id, title, status: 'skip', detail });
const na = (id, title, detail) => ({ id, title, status: 'na', blocking: true, detail });

export async function h1ByteEquality(ctx) {
  const title = 'the bytes a save sends are the bytes a read returns';
  if (!ctx.fixtures.length) {
    return na('H1', title, 'the conformance fixtures could not be found, so there is nothing to round-trip');
  }
  const results = [];
  for (const fixture of ctx.fixtures) {
    const saved = await ctx.client.save(ctx.doc, fixture.document);
    if (saved.status < 200 || saved.status >= 300) {
      return fail('H1', title, `${fixture.name}: save answered ${saved.status}`);
    }
    const read = await ctx.client.read(ctx.doc);
    if (stripHostAttrs(read.text) !== stripHostAttrs(fixture.document)) {
      return fail('H1', title, `${fixture.name}: read-back bytes differ from the saved bytes`);
    }
    results.push(fixture.name);
  }
  return pass('H1', title, `${results.length} fixture(s) round-tripped`);
}

export async function h2ServingIsPure(ctx) {
  const title = 'serving never mutates the stored document';
  await ctx.client.save(ctx.doc, DOC('<p>pure</p>'));
  const first = await ctx.client.read(ctx.doc);
  const baseline = sha256(stripHostAttrs(first.text));
  for (let i = 0; i < 200; i++) {
    const again = await ctx.client.read(ctx.doc);
    if (again.status !== 200) return fail('H2', title, `read ${i} answered ${again.status}`);
    if (sha256(stripHostAttrs(again.text)) !== baseline) {
      return fail('H2', title, `read ${i} returned different bytes`);
    }
  }
  return pass('H2', title, '200 reads, digest unchanged');
}

export async function h3Token(ctx) {
  const title = 'an injected save token is accepted on its own route and never duplicated';
  await ctx.client.save(ctx.doc, DOC('<p>token</p>'));
  const served = await ctx.client.read(ctx.doc);
  const token = getRootAttr(served.text, 'savetoken') || getRootAttr(served.text, 'htmlclaytoken');
  if (!token) return skip('H3-TOKEN', title, 'this host injects no save token for this document');

  const saved = await ctx.client.saveTo(`/_/save/${encodeURIComponent(token)}`, served.text);
  if (saved.status < 200 || saved.status >= 300) {
    return fail('H3-TOKEN', title, `a save carrying the host's own token answered ${saved.status}`);
  }

  const again = await ctx.client.read(ctx.doc);
  const span = rootTagSpan(again.text);
  const occurrences = (span?.attrs.match(/savetoken\s*=/gi) || []).length;
  if (occurrences > 1) return fail('H3-TOKEN', title, 'the root tag accumulated more than one savetoken');
  return pass('H3-TOKEN', title, 'token accepted and never duplicated');
}

export async function h3Strip(ctx) {
  const title = 'the save token a host injects never reaches the stored bytes';
  if (!ctx.storedRoot) {
    return skip('H3-STRIP', title, 'stored bytes cannot be read without --root');
  }
  const served = await ctx.client.read(ctx.doc);
  const token = getRootAttr(served.text, 'savetoken') || getRootAttr(served.text, 'htmlclaytoken');
  if (!token) return skip('H3-STRIP', title, 'this host injects no save token for this document');

  const storedPath = path.join(ctx.storedRoot, ctx.doc);
  let stored;
  try {
    stored = await readFile(storedPath, 'utf8');
  } catch (error) {
    return na('H3-STRIP', title, `cannot read the stored bytes at ${storedPath}: ${error?.message || error}`);
  }
  const span = rootTagSpan(stored);
  const attrs = span?.attrs ?? '';
  for (const name of ['savetoken', 'htmlclaytoken']) {
    if (new RegExp(`(?:^|\\s)${name}\\s*=`, 'i').test(attrs)) {
      return fail('H3-STRIP', title, `the stored root tag still carries ${name}`);
    }
  }
  return pass('H3-STRIP', title, 'the stored root tag carries no serve-time token');
}

export async function h4Identity(ctx) {
  const title = 'a document identity round-trips when the client carries it back';
  await ctx.client.save(ctx.doc, DOC('<p>identity</p>'));
  const served = await ctx.client.read(ctx.doc);
  const id = getRootAttr(served.text, 'documentid') || getRootAttr(served.text, 'htmlclayid');
  if (!id) return skip('H4-IDENTITY', title, 'this host injects no document identity');

  const saveBack = await ctx.client.save(ctx.doc, served.text);
  if (saveBack.status < 200 || saveBack.status >= 300) {
    return fail('H4-IDENTITY', title, `save-back answered ${saveBack.status}`);
  }
  const reserved = await ctx.client.read(ctx.doc);
  if ((getRootAttr(reserved.text, 'documentid') || getRootAttr(reserved.text, 'htmlclayid')) !== id) {
    return fail('H4-IDENTITY', title, 'the identity changed across a save-back');
  }
  return pass('H4-IDENTITY', title, 'identity stable on save-back');
}

export async function h5Meta(ctx) {
  const title = '/_/meta answers a capability document or a clean 404, never anything else';
  const res = await ctx.client.meta(null);
  if (res.status === 404) return pass('H5', title, 'clean 404: a bare core host');
  if (res.status < 200 || res.status >= 300) return fail('H5', title, `answered ${res.status}`);
  if (!res.json || typeof res.json !== 'object') return fail('H5', title, 'body is not a JSON object');
  if (typeof res.json.spec !== 'number') return fail('H5', title, '`spec` is not a number');
  if (res.json.extensions && !Array.isArray(res.json.extensions)) {
    return fail('H5', title, '`extensions` is not an array');
  }
  return pass('H5', title, `spec ${res.json.spec}, extensions [${(res.json.extensions || []).join(', ')}]`);
}

export async function h6MetaAntiProbe(ctx) {
  const title = '/_/meta cannot be used to probe for documents a caller cannot see';
  const probe = await ctx.client.metaHost('/definitely-not-here-9d3f2a.html');
  if (probe.status === 404) return pass('H6', title, 'discovery is off entirely');
  if (probe.json?.document !== undefined) {
    return fail('H6', title, 'a nonexistent document got a document block');
  }
  const second = await ctx.client.metaHost('/also-not-here-77c1b0.html');
  if (probe.text !== second.text) {
    return fail('H6', title, 'two nonexistent documents got different answers');
  }
  return pass('H6', title, 'withheld by omission, byte-identical');
}

export async function h7Conditional(ctx) {
  const title = 'a stale If-Match refuses with 412 and writes nothing';
  const capabilities = await ctx.client.meta(null);
  if (!capabilities.json?.extensions?.includes('conditional')) {
    return skip('H7', title, 'this host does not advertise `conditional`');
  }
  await ctx.client.save(ctx.doc, DOC('<p>conditional</p>'));
  const before = await ctx.client.read(ctx.doc);
  const beforeHash = sha256(stripHostAttrs(before.text));

  const stale = await ctx.client.save(ctx.doc, DOC('<p>should not land</p>'), {
    'If-Match': '0000000000000000',
  });
  if (stale.status !== 412) return fail('H7', title, `answered ${stale.status}, expected 412`);
  if (stale.json && stale.json.code !== 'conflict') {
    return fail('H7', title, `code was ${stale.json.code}, expected conflict`);
  }
  const after = await ctx.client.read(ctx.doc);
  if (sha256(stripHostAttrs(after.text)) !== beforeHash) {
    return fail('H7', title, 'the document changed despite the 412');
  }
  return pass('H7', title, '412 conflict, document untouched');
}

export async function h8Origin(ctx) {
  const title = 'cross-origin saves are refused, and Origin: null without a token is refused';
  await ctx.client.save(ctx.doc, DOC('<p>origin</p>'));
  const before = await ctx.client.read(ctx.doc);
  const beforeHash = sha256(stripHostAttrs(before.text));

  const cross = await ctx.client.save(ctx.doc, DOC('<p>cross-origin</p>'), {
    Origin: 'https://attacker.example',
    'Sec-Fetch-Site': 'cross-site',
  });
  if (cross.status < 400) return fail('H8', title, `a cross-origin save answered ${cross.status}`);

  const opaque = await ctx.client.save(ctx.doc, DOC('<p>opaque</p>'), {
    Origin: 'null',
    'Sec-Fetch-Site': 'cross-site',
  });
  if (opaque.status < 400) return fail('H8', title, `Origin: null answered ${opaque.status}`);

  const after = await ctx.client.read(ctx.doc);
  if (sha256(stripHostAttrs(after.text)) !== beforeHash) {
    return fail('H8', title, 'a refused save still changed the document');
  }
  return pass('H8', title, 'both refused, document untouched');
}

// Each spelling climbs one level above the served folder and names a canary this
// row creates there, so the row proves the real property (nothing outside the
// folder is served or changed) without naming any operating-system file.
const traversals = (name) => [
  `/../${name}`,
  `/..%2F${name}`,
  `/%2e%2e%2f${name}`,
  `/..%5c${name}`,
  `/notes/../../${name}`,
];

// A page reading a path outside its folder is a request a local host may put in
// front of the user. A browser's own navigation is not, so the read lane sends
// that metadata and a run never raises a dialog on the machine it runs on.
const NAVIGATION = { 'Sec-Fetch-Site': 'none', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Dest': 'document' };

const namesIn = async (dir) => {
  try {
    return new Set(await readdir(dir));
  } catch (error) {
    if (error.code === 'ENOENT') return new Set();
    throw error;
  }
};

export async function h9Traversal(ctx) {
  const title = 'path traversal is refused in every spelling';
  const name = `host-conformance-canary-${randomUUID()}.html`;
  const marker = `host-conformance-canary-${randomUUID()}`;
  const root = ctx.storedRoot ? path.resolve(ctx.storedRoot) : null;
  const parent = root ? path.dirname(root) : null;
  const canary = root ? path.join(parent, name) : null;
  if (!canary && ctx.client.hasToken()) return na('H9', title, 'a host using save tokens needs --root for this row: only a canary outside the folder can show the read lane is safe');
  if (canary) await writeFile(canary, marker);
  const created = new Set();
  let inside = 0;
  try {
    const attempts = traversals(name);
    for (const attempt of attempts) {
      const read = await ctx.client.readRaw(attempt, NAVIGATION);
      if (read.text.includes(marker)) {
        return fail('H9', title, `GET ${attempt} served a file from outside the folder`);
      }
      // A token names its document, so a Document-URL on that route is not a path
      // the host resolves. Only a host saving by header has a save lane to test.
      if (ctx.client.hasToken()) continue;
      const before = canary ? await namesIn(root) : null;
      const written = await ctx.client.saveRaw(`${ctx.base.replace(/\/$/, '')}${attempt}`, DOC('<p>escaped</p>'));
      if (!canary) {
        if (written.status < 400) {
          return fail('H9', title, `Document-URL ${attempt} was accepted with ${written.status}`);
        }
        continue;
      }
      // A host that creates a document on save may resolve the spelling inside its own
      // folder, which a browser does too. Only a write outside the folder is a failure.
      if ((await readFile(canary, 'utf8')) !== marker) {
        return fail('H9', title, `Document-URL ${attempt} changed a file outside the folder`);
      }
      const after = await namesIn(root);
      for (const entry of after) if (!before.has(entry)) created.add(entry);
      if (after.has(path.relative(root, path.join(root, new URL(attempt, ctx.base).pathname)))) {
        inside += 1;
      }
    }
    if (canary) {
      const stem = name.replace(/\.html$/, '');
      const stray = [...await namesIn(parent)].filter((entry) => entry !== name && entry.includes(stem));
      if (stray.length) {
        return fail('H9', title, `a spelling created ${stray[0]} outside the folder`);
      }
    }
    const lanes = ctx.client.hasToken() ? 'read lane only, because a token names its document' : 'read and save lanes';
    const scope = canary ? 'against a canary outside the folder' : 'by status only, because no --root was given';
    const wrote = canary && !ctx.client.hasToken() ? `, ${inside} written inside the folder after URL normalization` : '';
    return pass('H9', title, `${attempts.length} spellings refused, ${lanes}, ${scope}${wrote}`);
  } finally {
    if (canary) {
      for (const entry of created) await rm(path.join(root, entry), { force: true });
      await rm(canary, { force: true });
    }
  }
}

export async function h10Refused(ctx) {
  const title = 'a non-document body and a JSON envelope are refused with an authoritative status';
  const notHtml = await ctx.client.save(ctx.doc, 'this is not a document');
  const envelope = await ctx.client.save(ctx.doc, JSON.stringify({ content: DOC('<p>json</p>') }), {
    'Content-Type': 'application/json',
    'Document-URL': new URL(ctx.doc, ctx.base).href,
  });

  const answers = [['a non-document body', notHtml], ['a JSON envelope', envelope]];
  for (const [label, answer] of answers) {
    if (answer.status >= 200 && answer.status < 300) {
      return fail('H10-REFUSED', title, `${label} was accepted with ${answer.status}`);
    }
    if (answer.json !== null) {
      const msg = answer.json && typeof answer.json === 'object' ? answer.json.msg : undefined;
      if (typeof msg !== 'string' || !msg) {
        const keys = answer.json && typeof answer.json === 'object' ? Object.keys(answer.json).join(', ') : '';
        return fail('H10-REFUSED', title, `${label} answered ${answer.status} with JSON keys [${keys}] and no msg`);
      }
    }
  }
  return pass('H10-REFUSED', title, `${notHtml.status} and ${envelope.status}, both authoritative`);
}

export async function h11SizeCap(ctx) {
  const title = 'an over-limit body is 413 with no partial write';
  await ctx.client.save(ctx.doc, DOC('<p>sized</p>'));
  const capabilities = await ctx.client.meta(ctx.doc);
  const limit = capabilities.json?.document?.maxBytes;
  if (!limit) return skip('H11', title, 'this host does not advertise a size limit');

  const before = await ctx.client.read(ctx.doc);
  const beforeHash = sha256(stripHostAttrs(before.text));

  const huge = DOC(`<p>${'x'.repeat(limit + 1024)}</p>`);
  const res = await ctx.client.save(ctx.doc, huge);
  if (res.status !== 413) return fail('H11', title, `answered ${res.status}, expected 413`);

  const after = await ctx.client.read(ctx.doc);
  if (sha256(stripHostAttrs(after.text)) !== beforeHash) {
    return fail('H11', title, 'the document changed despite the 413');
  }
  return pass('H11', title, '413, document untouched');
}

export async function h12CrashSafety(ctx) {
  const title = 'a kill mid-write leaves the previous document intact';
  if (!ctx.faultInjector) {
    return na('H12-CRASH', title, 'no fault injector was provided');
  }
  return await ctx.faultInjector(ctx);
}

export const ASSERTIONS = [
  { run: h1ByteEquality, id: 'h1' },
  { run: h2ServingIsPure, id: 'h2' },
  { run: h3Token, id: 'h3-token' },
  { run: h3Strip, id: 'h3-strip' },
  { run: h4Identity, id: 'h4-identity' },
  { run: h5Meta, id: 'h5' },
  { run: h6MetaAntiProbe, id: 'h6' },
  { run: h7Conditional, id: 'h7' },
  { run: h8Origin, id: 'h8' },
  { run: h9Traversal, id: 'h9' },
  { run: h10Refused, id: 'h10-refused' },
  { run: h11SizeCap, id: 'h11' },
  { run: dataGuardRestore, id: 'data-guard-restore' },
  { run: dataGuardRefusals, id: 'data-guard-refusals' },
  { run: dataGuardNotified, id: 'data-guard-notified' },
  { run: h12CrashSafety, id: 'h12-crash', profile: 'crash' },
];

// An assertion that throws never reaches its own title, and a report that reads
// `h9Traversal` instead of the sentence tells a host author nothing.
export const TITLES = {
  H1: 'the bytes a save sends are the bytes a read returns',
  H2: 'serving never mutates the stored document',
  'H3-TOKEN': 'an injected save token is accepted on its own route and never duplicated',
  'H3-STRIP': 'the save token a host injects never reaches the stored bytes',
  'H4-IDENTITY': 'a document identity round-trips when the client carries it back',
  H5: '/_/meta answers a capability document or a clean 404, never anything else',
  H6: '/_/meta cannot be used to probe for documents a caller cannot see',
  H7: 'a stale If-Match refuses with 412 and writes nothing',
  H8: 'cross-origin saves are refused, and Origin: null without a token is refused',
  H9: 'path traversal is refused in every spelling',
  'H10-REFUSED': 'a non-document body and a JSON envelope are refused with an authoritative status',
  H11: 'an over-limit body is 413 with no partial write',
  'H12-CRASH': 'a kill mid-write leaves the previous document intact',
  'DATA-GUARD-RESTORE': 'a guard event restores lost data onto the current page',
  'DATA-GUARD-REFUSALS': 'the guard refuses a bad id, bad choice, impossible restore and a second dismiss',
  'DATA-GUARD-NOTIFIED': 'a raised and a resolved guard event reach the live lane',
};

export { DOC };
