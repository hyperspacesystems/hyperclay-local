import { sha256 } from './http.js';
import { stripHostAttrs } from './root-attrs.js';

// The data-guard rows. A host that keeps a record of saved data may tell a
// client when a write destroyed it, and these rows prove the whole wire
// contract: the event, the three refusals, and the live-lane notification.

const ITEMS = ['Alpha', 'Bravo', 'Charlie', 'Delta'];
const MARKER_OLD = 'layout-a';
const MARKER_NEW = 'layout-b';
const POLL_MS = 10000;
const EVENT_KEYS = [
  'id',
  'firstDetectedAt',
  'lastWriteAt',
  'lossSummary',
  'fieldCount',
  'preview',
  'droppedAdditions',
  'restorable',
  'canRevert',
  'status',
];

const pass = (id, title, detail = '') => ({ id, title, status: 'pass', detail });
const fail = (id, title, detail) => ({ id, title, status: 'fail', detail });
const skip = (id, title, detail) => ({ id, title, status: 'skip', detail });
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const fixture = ({ items = ITEMS, marker = MARKER_OLD } = {}) =>
  `<!DOCTYPE html>\n<html lang="en">\n<head><meta charset="utf-8"><title>Conformance</title></head>\n<body>\n<h1>Conformance</h1>\n<script type="application/json" data-rules-name="api" data-rules-version="1">{"title": "h1", "items": ".item[]"}</script>\n<ul>\n${items.map((item) => `<li class="item">${item}</li>`).join('\n')}\n</ul>\n<div class="layout-marker">${marker}</div>\n</body>\n</html>\n`;

const itemTexts = (html) =>
  [...html.matchAll(/<li[^>]*class="[^"]*\bitem\b[^"]*"[^>]*>([\s\S]*?)<\/li>/gi)]
    .map((match) => match[1].trim());

const hasNoStore = (response) => /no-store/i.test(response.headers.get('cache-control') || '');

// `preview` rows show what changed, truncated (the notice prints the first one), so they may name
// items. Everything else in the event must not carry the recoverable data itself, and no part may
// name where the host keeps its backup.
const leaksRecoverableData = (text) => {
  let rest = text;
  try {
    const body = JSON.parse(text);
    if (body?.event && typeof body.event === 'object') {
      const { preview, ...others } = body.event;
      rest = JSON.stringify({ ...body, event: others });
    }
  } catch {
    rest = text;
  }
  return ITEMS.some((item) => rest.includes(item)) || /\.recover|\.hyperclay\/guard|recover[\\/]/i.test(text);
};

const errorText = (body) => (typeof body?.error === 'string' ? body.error.trim() : '');

function announced(meta) {
  return Array.isArray(meta.json?.extensions) ? meta.json.extensions : [];
}

async function createContext(ctx, meta, extensions) {
  const href = meta.json?.document?.dataGuard?.href;
  if (typeof href !== 'string' || href === '') {
    return { fail: 'document.dataGuard.href is not a non-empty string' };
  }
  const state = {
    href,
    target: new URL(ctx.doc, ctx.base).href,
    conditional: extensions.includes('conditional'),
  };

  const getEvent = () => ctx.client.read(href, { headers: { 'Document-URL': state.target } });
  const post = (body) => ctx.client.read(href, {
    method: 'POST',
    headers: {
      'Document-URL': state.target,
      'Content-Type': 'application/json',
      Origin: new URL(ctx.base).origin,
      'Sec-Fetch-Site': 'same-origin',
    },
    body: JSON.stringify(body),
  });

  const current = await getEvent();
  if (current.json?.event?.id) {
    await post({ id: current.json.event.id, choice: 'dismiss' });
  }

  const seeded = await save(ctx, state, fixture(), 'user');
  if (seeded.status < 200 || seeded.status >= 300) {
    return { fail: `saving the four-item probe document answered ${seeded.status}` };
  }
  const zero = await getEvent();
  await sleep(1000);
  return { state, getEvent, post, zero };
}

async function save(ctx, state, body, trigger) {
  const headers = {};
  if (trigger) headers['Save-Trigger'] = trigger;
  // A resolve rewrites the document, so the stamp is read fresh before every save. It is
  // the stamp the spec defines, `/_/meta`'s `document.etag`: a GET's HTTP ETag header is
  // not it on every host.
  if (state.conditional) {
    const described = await ctx.client.meta(ctx.doc);
    const etag = described.json?.document?.etag;
    if (typeof etag === 'string' && etag) headers['If-Match'] = etag;
  }
  return ctx.client.save(ctx.doc, body, headers);
}

async function prepare(ctx, meta = null) {
  const read = meta || await ctx.client.meta(ctx.doc);
  const extensions = announced(read);
  if (!extensions.includes('data-guard-v1')) {
    return { skip: 'Host does not declare data-guard-v1.' };
  }
  return await createContext(ctx, read, extensions);
}

async function pendingEvent(getEvent, timeoutMs = POLL_MS) {
  const deadline = Date.now() + timeoutMs;
  let last = null;
  while (Date.now() <= deadline) {
    last = await getEvent();
    if (last.json?.event && last.json.event.status === 'pending') {
      return { response: last, event: last.json.event };
    }
    await sleep(100);
  }
  return { response: last, event: last?.json?.event ?? null };
}

async function waitFrame(frames, predicate, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() <= deadline) {
    const found = frames.find(predicate);
    if (found) return found;
    await sleep(25);
  }
  return null;
}

export async function dataGuardRestore(ctx) {
  const id = 'DATA-GUARD-RESTORE';
  const title = 'a guard event restores lost data onto the current page';
  const prepared = await prepare(ctx);
  if (prepared.skip) return skip(id, title, prepared.skip);
  if (prepared.fail) return fail(id, title, prepared.fail);

  const clobbered = await save(ctx, prepared.state, fixture({ items: [ITEMS[0]], marker: MARKER_NEW }), null);
  if (clobbered.status < 200 || clobbered.status >= 300) {
    return fail(id, title, `the destructive save answered ${clobbered.status}`);
  }

  const { response, event } = await pendingEvent(prepared.getEvent);
  if (!event || event.status !== 'pending') {
    return fail(id, title, 'the guard raised no pending event within 10 s');
  }
  if (!hasNoStore(prepared.zero)) {
    return fail(id, title, 'the null event answer did not carry Cache-Control: no-store');
  }
  if (!hasNoStore(response)) {
    return fail(id, title, 'the pending event answer did not carry Cache-Control: no-store');
  }
  const missing = EVENT_KEYS.filter((key) => !Object.prototype.hasOwnProperty.call(event, key));
  if (missing.length) return fail(id, title, `the event is missing ${missing.join(', ')}`);
  if (event.status !== 'pending') return fail(id, title, `status was ${event.status}, expected pending`);
  if (event.restorable !== true) return fail(id, title, 'restorable was not true');
  if (leaksRecoverableData(response.text)) {
    return fail(id, title, 'the event exposed raw recoverable data or a backup identifier');
  }

  const restored = await prepared.post({ id: event.id, choice: 'restore' });
  if (restored.status !== 200) return fail(id, title, `restore answered ${restored.status}, expected 200`);
  if (restored.json?.ok !== true || restored.json?.choice !== 'restore' || restored.json?.status !== 'restored') {
    return fail(id, title, `restore answered ${restored.text.slice(0, 160)}`);
  }

  const after = await prepared.getEvent();
  if (!after.json || after.json.event !== null) {
    return fail(id, title, 'a second GET did not answer {event: null}');
  }

  const served = await ctx.client.read(ctx.doc);
  const texts = itemTexts(served.text);
  if (texts.length !== ITEMS.length || !ITEMS.every((item) => texts.includes(item))) {
    return fail(id, title, `the fetched document holds ${texts.length} item(s), expected ${ITEMS.length}`);
  }
  if (!served.text.includes(MARKER_NEW)) {
    return fail(id, title, 'the fetched document did not keep the newer layout marker');
  }
  return pass(id, title, 'restored four items and kept the newer layout marker');
}

export async function dataGuardRefusals(ctx) {
  const id = 'DATA-GUARD-REFUSALS';
  const title = 'the guard refuses a bad id, bad choice, impossible restore and a second dismiss';
  const prepared = await prepare(ctx);
  if (prepared.skip) return skip(id, title, prepared.skip);
  if (prepared.fail) return fail(id, title, prepared.fail);
  const { state, getEvent, post } = prepared;

  const clobbered = await save(ctx, state, fixture({ items: [ITEMS[0]], marker: MARKER_NEW }), null);
  if (clobbered.status < 200 || clobbered.status >= 300) {
    return fail(id, title, `the destructive save answered ${clobbered.status}`);
  }
  const { response: pendingResponse, event } = await pendingEvent(getEvent);
  if (!event || event.status !== 'pending') {
    return fail(id, title, 'the guard raised no pending event within 10 s');
  }

  const beforeBytes = sha256(stripHostAttrs((await ctx.client.read(ctx.doc)).text));

  const wrongId = await post({ id: 'not-this-event', choice: 'restore' });
  if (wrongId.status !== 409) return fail(id, title, `a wrong id answered ${wrongId.status}, expected 409`);
  if (!errorText(wrongId.json)) return fail(id, title, 'a wrong id answered no error');
  if ((await getEvent()).text !== pendingResponse.text) return fail(id, title, 'a wrong id changed the event');
  if (sha256(stripHostAttrs((await ctx.client.read(ctx.doc)).text)) !== beforeBytes) {
    return fail(id, title, 'a wrong id changed the document');
  }

  const wrongChoice = await post({ id: event.id, choice: 'explode' });
  if (wrongChoice.status !== 400) return fail(id, title, `an unknown choice answered ${wrongChoice.status}, expected 400`);
  if (!errorText(wrongChoice.json)) return fail(id, title, 'an unknown choice answered no error');
  if ((await getEvent()).text !== pendingResponse.text) return fail(id, title, 'an unknown choice changed the event');
  if (sha256(stripHostAttrs((await ctx.client.read(ctx.doc)).text)) !== beforeBytes) {
    return fail(id, title, 'an unknown choice changed the document');
  }

  const emptied = await save(ctx, state, fixture({ items: [], marker: MARKER_NEW }), null);
  if (emptied.status < 200 || emptied.status >= 300) {
    return fail(id, title, `emptying the item list answered ${emptied.status}`);
  }
  const noClone = await getEvent();
  if (!noClone.json?.event || noClone.json.event.status !== 'pending') {
    return fail(id, title, 'emptying the item list left no pending event');
  }
  if (noClone.json.event.restorable !== false) {
    return fail(id, title, 'restorable stayed true with no item left to clone');
  }
  const impossible = await post({ id: noClone.json.event.id, choice: 'restore' });
  if (impossible.status !== 422) {
    return fail(id, title, `restore with no clonable item answered ${impossible.status}, expected 422`);
  }
  if (!errorText(impossible.json)) return fail(id, title, 'an impossible restore answered no error');

  const revertable = await getEvent();
  if (revertable.json?.event?.canRevert !== true) {
    return fail(id, title, 'canRevert was not true before revert');
  }
  const reverted = await post({ id: revertable.json.event.id, choice: 'revert' });
  if (reverted.status !== 200) return fail(id, title, `revert answered ${reverted.status}, expected 200`);
  if (reverted.json?.choice !== 'revert' || reverted.json?.status !== 'reverted') {
    return fail(id, title, `revert answered ${reverted.text.slice(0, 160)}`);
  }

  const finalClobber = await save(ctx, state, fixture({ items: [ITEMS[0]], marker: MARKER_NEW }), null);
  if (finalClobber.status < 200 || finalClobber.status >= 300) {
    return fail(id, title, `the final destructive save answered ${finalClobber.status}`);
  }
  const final = await pendingEvent(getEvent);
  if (!final.event) return fail(id, title, 'the final clobber raised no pending event');
  const dismissed = await post({ id: final.event.id, choice: 'dismiss' });
  if (dismissed.status !== 200) return fail(id, title, `dismiss answered ${dismissed.status}, expected 200`);
  if (dismissed.json?.choice !== 'dismiss' || dismissed.json?.status !== 'dismissed') {
    return fail(id, title, `dismiss answered ${dismissed.text.slice(0, 160)}`);
  }
  const again = await post({ id: final.event.id, choice: 'dismiss' });
  if (again.status !== 404) return fail(id, title, `a second dismiss answered ${again.status}, expected 404`);
  if (!errorText(again.json)) return fail(id, title, 'a second dismiss answered no error');

  return pass(id, title, '409, 400, 422, reverted, dismissed and 404');
}

export async function dataGuardNotified(ctx) {
  const id = 'DATA-GUARD-NOTIFIED';
  const title = 'a raised and a resolved guard event reach the live lane';
  const meta = await ctx.client.meta(ctx.doc);
  const extensions = announced(meta);
  if (!extensions.includes('data-guard-v1')) {
    return skip(id, title, 'Host does not declare data-guard-v1.');
  }
  if (!extensions.includes('sync')) {
    return skip(id, title, 'Host does not declare sync.');
  }
  const prepared = await prepare(ctx, meta);
  if (prepared.skip) return skip(id, title, prepared.skip);
  if (prepared.fail) return fail(id, title, prepared.fail);

  const url = new URL('/_/sync', ctx.base);
  url.searchParams.set('s', `live:0:${prepared.state.target}`);
  const token = typeof ctx.client.token === 'function' ? ctx.client.token() : '';
  if (token) url.searchParams.set('token', token);

  const controller = new AbortController();
  let response;
  let reader;
  const frames = [];
  try {
    const opened = await Promise.race([
      fetch(url, { headers: { ...ctx.client.headers(), 'Sec-Fetch-Site': 'same-origin' }, signal: controller.signal }),
      sleep(2000).then(() => null),
    ]);
    if (!opened) return fail(id, title, 'the sync stream did not open within 2 s');
    response = opened;
    if (!response.ok) return fail(id, title, `the sync stream answered ${response.status}`);

    reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    (async () => {
      try {
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let at = buffer.indexOf('\n\n');
          while (at !== -1) {
            const block = buffer.slice(0, at);
            buffer = buffer.slice(at + 2);
            const data = block
              .split('\n')
              .filter((line) => line.startsWith('data:'))
              .map((line) => line.slice(5).trimStart())
              .join('\n');
            if (data) {
              try {
                frames.push(JSON.parse(data));
              } catch {}
            }
            at = buffer.indexOf('\n\n');
          }
        }
      } catch {}
    })();

    const clobbered = await save(ctx, prepared.state, fixture({ items: [ITEMS[0]], marker: MARKER_NEW }), null);
    if (clobbered.status < 200 || clobbered.status >= 300) {
      return fail(id, title, `the destructive save answered ${clobbered.status}`);
    }

    const raised = await waitFrame(
      frames,
      (frame) => frame?.type === 'notification' && frame.msgType === 'data-loss' && frame.action === 'raised',
      POLL_MS,
    );
    if (!raised) return fail(id, title, 'no raised notification frame arrived within 10 s');
    const current = await prepared.getEvent();
    if (!current.json?.event || raised.data?.id !== current.json.event.id) {
      return fail(id, title, 'the raised frame did not carry the pending event');
    }

    const dismissed = await prepared.post({ id: current.json.event.id, choice: 'dismiss' });
    if (dismissed.status !== 200) {
      return fail(id, title, `dismiss answered ${dismissed.status}`);
    }
    const resolved = await waitFrame(
      frames,
      (frame) => frame?.type === 'notification' && frame.msgType === 'data-loss' &&
        frame.action === 'resolved' && frame.data?.id === current.json.event.id,
      POLL_MS,
    );
    if (!resolved) return fail(id, title, 'no resolved notification frame arrived within 10 s');

    return pass(id, title, 'raised and resolved frames carried the event id');
  } finally {
    controller.abort();
    if (reader) {
      try {
        await reader.cancel();
      } catch {}
    }
  }
}
