import crypto from 'node:crypto';
import http from 'node:http';
import https from 'node:https';

// A tiny HTTP surface for the runner. Deliberately dependency-free: any host in
// any language should be able to run this with nothing but Node installed.

export function sha256(text) {
  return crypto.createHash('sha256').update(text ?? '').digest('hex');
}

export async function req(base, path, options = {}) {
  const url = new URL(path, base).href;
  const response = await fetch(url, {
    method: options.method || 'GET',
    headers: options.headers || {},
    body: options.body,
    redirect: 'manual',
  });
  const text = await response.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  return { status: response.status, headers: response.headers, text, json, url };
}

// A GET whose path and headers reach the host exactly as given. `fetch` resolves
// dot-segments and overwrites Sec-Fetch-Mode, so neither a traversal spelling nor
// a browser navigation can be expressed through it.
export function rawGet(base, rawPath, headers = {}) {
  const { protocol, hostname, port } = new URL(base);
  const transport = protocol === 'https:' ? https : http;
  return new Promise((resolve, reject) => {
    const request = transport.request({ hostname, port, path: rawPath, method: 'GET', headers }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => resolve({ status: response.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      response.on('error', reject);
    });
    request.on('error', reject);
    request.end();
  });
}

export function saveDoc(base, docPath, body, headers = {}) {
  return saveRaw(base, new URL(docPath, base).href, body, headers);
}

// Document-URL exactly as given, with no URL parsing on our side. The header is
// untrusted input a page chooses, so a traversal probe has to reach the host in
// the spelling it was written in; `new URL()` would resolve the dot-segments
// here and test nothing.
export function saveRaw(base, href, body, headers = {}) {
  return req(base, '/_/save', {
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain',
      'Document-URL': href,
      ...headers,
    },
    body,
  });
}

export function meta(base, docPath, headers = {}) {
  return req(base, '/_/meta', {
    headers: docPath ? { 'Document-URL': new URL(docPath, base).href, ...headers } : headers,
  });
}
