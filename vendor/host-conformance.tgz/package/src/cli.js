import { mkdir, readFile, writeFile } from 'node:fs/promises';

import path from 'node:path';

import { capabilityChecks, readAnnounced, registeredCheck } from './capabilities.js';
import { runFrozenEngine } from './frozen/engine.js';
import { runConformance } from './http-engine.js';
import { expectedIds, loadInventory, reconcileInventory } from './inventory.js';
import { runPageEngine, SERVED_NAME } from './page-engine.js';
import { buildReport, exitCode, redactTokens } from './report.js';
import { applyWaivers, loadWaivers } from './waivers.js';

// One command, both engines, one report. The exit code is the contract with
// hypersave, so it is decided by the report and nothing else.

const VERSION = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')).version;
const INVENTORY = new URL('../checks.json', import.meta.url);
const REGISTRY = new URL('../extension-registry.json', import.meta.url);
const DEFAULT_WAIVERS = './conformance-waivers.json';

const USAGE = `host-conformance --url <origin> [options]

  --engine <all|page|http|frozen>   default all
  --host <name>              recorded in the report
  --root <dir>               page engine: copy the page into this served folder when --page is absent; http engine: read stored bytes here
  --page <name>              page engine: the host already serves the page at this name
  --doc <path>               http engine: the probe document, default /_conformance-probe.html
  --token-from-page          take the save token the host injected
  --token <value>            a known token
  --target <path>            page engine: passed through to the page
  --cookie name=value        repeatable, sent by both engines
  --insecure                 accept a dev certificate
  --report <file>            write the JSON report here. Falls back to $CONFORMANCE_REPORT.
  --waivers <file>           default ./conformance-waivers.json when that file exists
  --require-extensions <names>  comma-separated extensions this host must announce
  --only <ids>               comma-separated check ids
  --profile <name>           run the checks in this profile too (e.g. crash), which an ordinary run leaves out
  --keep                     leave the page and scratch document in place

Exit codes: 0 nothing failed, 1 a check failed, 3 the run could not answer.
`;

const VALUE_FLAGS = new Set([
  '--url', '--engine', '--host', '--root', '--page', '--doc', '--token',
  '--target', '--cookie', '--report', '--waivers', '--require-extensions', '--only', '--profile',
]);
const TOGGLE_FLAGS = new Set(['--token-from-page', '--insecure', '--keep', '--help', '-h']);

function parseFlags(argv) {
  const options = { cookies: [], tokenFromPage: false, insecure: false, keep: false, help: false };
  for (let i = 0; i < argv.length; i += 1) {
    const flag = argv[i];
    if (TOGGLE_FLAGS.has(flag)) {
      if (flag === '--help' || flag === '-h') options.help = true;
      else if (flag === '--token-from-page') options.tokenFromPage = true;
      else if (flag === '--insecure') options.insecure = true;
      else options.keep = true;
      continue;
    }
    if (!VALUE_FLAGS.has(flag)) throw withOptions(new Error(`unknown flag ${flag}`), options);
    if (i + 1 >= argv.length) throw withOptions(new Error(`${flag} needs a value`), options);
    const value = argv[i + 1];
    i += 1;
    if (flag === '--cookie') options.cookies.push(value);
    else if (flag === '--url') options.url = value;
    else if (flag === '--engine') options.engine = value;
    else if (flag === '--host') options.host = value;
    else if (flag === '--root') options.root = value;
    else if (flag === '--page') options.page = value;
    else if (flag === '--doc') options.doc = value;
    else if (flag === '--token') options.token = value;
    else if (flag === '--target') options.target = value;
    else if (flag === '--report') options.report = value;
    else if (flag === '--waivers') options.waivers = value;
    else if (flag === '--require-extensions') options.requireExtensions = value;
    else if (flag === '--only') options.only = value;
    else if (flag === '--profile') options.profile = value;
  }
  return options;
}

function withOptions(error, options) {
  error.options = options;
  return error;
}

function splitList(value) {
  return (value ?? '').split(',').map((entry) => entry.trim().toLowerCase()).filter(Boolean);
}

// An unreachable host is unanswered, not a verdict: the engine reports a
// transport failure that way row by row, and the discovery read has to answer
// the same way rather than abort the run.
async function announcedRead(options) {
  try {
    return await readAnnounced({ url: options.url, cookies: options.cookies });
  } catch (error) {
    return {
      state: 'unreadable',
      names: [],
      detail: `could not reach the host: ${error?.message || error}`,
    };
  }
}

async function collect(options) {
  if (!options.url) throw new Error("--url is required (the host's origin, e.g. http://127.0.0.1:4321)");
  const engine = options.engine ?? 'all';
  if (!['all', 'page', 'http', 'frozen'].includes(engine)) throw new Error(`--engine wants all, page, http or frozen, got ${engine}`);

  const required = splitList(options.requireExtensions);
  const only = splitList(options.only);

  const addRegistered = only.length === 0;

  const inventory = await loadInventory(INVENTORY);
  const registry = new Set(
    JSON.parse(await readFile(REGISTRY, 'utf8')).names.map((entry) => entry.name),
  );
  const expected = expectedIds(inventory, {
    engine,
    only,
    profile: options.profile ?? null,
    extra: [
      ...required.map((name) => `capability.${name}`),
      ...(addRegistered ? ['capability.registered'] : []),
    ],
  });

  if (only.length) {
    const unknown = only.filter((id) => !expectedIds(inventory, { engine, only: [id], profile: options.profile ?? null }).length);
    if (unknown.length || !expected.length) {
      throw new Error(`--only names checks this run does not have: ${(unknown.length ? unknown : only).join(', ')}`);
    }
  }

  const checks = [];

  if (required.length || addRegistered) {
    const read = await announcedRead(options);
    if (required.length) checks.push(...capabilityChecks(read.names, required));
    if (addRegistered) checks.push(registeredCheck(read, registry));
  }

  if (engine === 'all' || engine === 'page') {
    if (!options.root && !options.page) {
      throw new Error('the page engine needs --root (copy the page into a served folder) or --page (the host already serves it)');
    }
    const result = await runPageEngine({
      url: options.url,
      root: options.root ?? '',
      page: options.page || SERVED_NAME,
      place: !options.page,
      token: options.token ?? '',
      target: options.target ?? '',
      cookies: options.cookies,
      tokenFromPage: options.tokenFromPage,
      insecure: options.insecure,
      keep: options.keep,
    });
    // A page that produced no rows is a broken harness, not a clean host.
    if (!result.checks.length) throw new Error('the page engine produced no results: the run did not happen');
    checks.push(...result.checks);
  }

  if (engine === 'all' || engine === 'frozen') {
    if (!options.root && !options.page) {
      throw new Error('the frozen engine needs --root (copy the document into a served folder) or --page (the host already serves it)');
    }
    const result = await runFrozenEngine({
      url: options.url,
      host: options.host ?? null,
      root: options.root ?? '',
      page: options.page ?? '',
      cookies: options.cookies,
      only: only.length ? only : null,
      token: options.token ?? '',
      insecure: options.insecure,
      keep: options.keep,
    });
    checks.push(...result.checks);
  }

  if (engine === 'all' || engine === 'http') {
    const result = await runConformance({
      base: options.url,
      doc: options.doc,
      only: only.length ? only : null,
      profile: options.profile ?? null,
      storedRoot: options.root ?? null,
      cookies: options.cookies,
      tokenFromPage: options.tokenFromPage,
      token: options.token ?? '',
    });
    checks.push(...result.checks);
  }

  const listed = new Set(inventory.map((check) => check.id));
  const selected = only.length
    ? checks.filter((check) => !listed.has(check.id) || expected.includes(check.id))
    : checks;

  const reconciled = reconcileInventory(selected, { expected, inventory });
  const waivers = await loadWaivers(options.waivers ?? DEFAULT_WAIVERS, { required: Boolean(options.waivers) });
  return applyWaivers(reconciled, waivers, {
    known: new Set([...inventory.map((check) => check.id), ...expected]),
  });
}

const PRINT_ORDER = { 'waiver-unused': 0, fail: 1, na: 2, skip: 3, waived: 4, pass: 5 };

function printChecks(report) {
  const width = Math.max(...report.checks.map((check) => check.status.length));
  for (const check of [...report.checks].sort((a, b) => PRINT_ORDER[a.status] - PRINT_ORDER[b.status])) {
    console.log(`${check.status.toUpperCase().padEnd(width)}  ${check.id}  ${redactTokens(check.detail ?? '')}`.trimEnd());
  }
  const { summary } = report;
  console.log(
    `\n${summary.pass} passed, ${summary.fail} failed, ${summary.skip} skipped, ` +
    `${summary.waived} waived, ${summary.unused} waived-but-passing, ${summary.unanswered} unanswered`,
  );
}

export async function main(argv) {
  const startedAt = new Date().toISOString();
  let options;
  try {
    options = parseFlags(argv);
  } catch (error) {
    console.error(error.message);
    console.error(USAGE);
    return 3;
  }
  if (options.insecure) process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  if (options.help) {
    console.log(USAGE);
    return 0;
  }

  let report;
  try {
    const checks = await collect(options);
    report = buildReport({ host: options.host, url: options.url, startedAt, checks, version: VERSION });
  } catch (error) {
    const detail = redactTokens(error?.message || String(error));
    console.error(detail);
    // An engine that could not start, or a waiver file that does not hold up, is
    // not a verdict about the host. It still gets a report, so hypersave can say
    // what stopped the run instead of inferring it from an exit code alone.
    report = buildReport({
      host: options.host,
      url: options.url ?? null,
      startedAt,
      version: VERSION,
      checks: [{
        id: 'runner.error',
        title: 'the run could not answer',
        engine: null,
        status: 'na',
        rawStatus: 'na',
        detail,
        blocking: true,
        waiver: null,
      }],
    });
  }

  printChecks(report);

  const reportPath = options.report ?? process.env.CONFORMANCE_REPORT ?? null;
  if (reportPath) {
    try {
      await mkdir(path.dirname(reportPath), { recursive: true });
      await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
    } catch (error) {
      console.error(`cannot write ${reportPath}: ${error.message || error}`);
      return 3;
    }
  }

  const code = exitCode(report);
  if (code === 3) console.error('\nThe run could not answer: see the unanswered checks above.');
  return code;
}
