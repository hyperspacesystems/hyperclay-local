import { rawGet, req } from './http.js';
import { getRootAttr } from './root-attrs.js';

export function createClient({ base, doc, cookies = [], headers = {}, tokenFromPage = false, token: given = '' }) {
  const shared = { ...headers, ...(cookies.length ? { cookie: cookies.join('; ') } : {}) };
  let token = given;

  async function resolveToken() {
    if (!tokenFromPage || token) return;
    const page = await req(base, doc, { headers: shared });
    token = getRootAttr(page.text, 'savetoken') || '';
    if (!token) throw new Error(`--token-from-page: ${doc} was served with no savetoken attribute`);
  }

  const route = () => (token ? `/_/save/${encodeURIComponent(token)}` : '/_/save');
  const merged = (extra) => Object.fromEntries(Object.entries({ ...shared, ...extra }).filter(([, value]) => value !== undefined));

  return {
    resolveToken,
    hasToken: () => Boolean(token),
    token: () => token,
    headers: () => ({ ...shared }),
    readRaw: (rawPath, extra = {}) => rawGet(base, rawPath, merged(extra)),
    read: (path, options = {}) => req(base, path, { ...options, headers: merged(options.headers) }),
    meta: (path, extra = {}) => req(base, token ? `/_/meta/${encodeURIComponent(token)}` : '/_/meta', {
      headers: merged({ ...(path ? { 'Document-URL': new URL(path, base).href } : {}), ...extra }),
    }),
    metaHost: (path, extra = {}) => req(base, '/_/meta', {
      headers: merged({ ...(path ? { 'Document-URL': new URL(path, base).href } : {}), ...extra }),
    }),
    save: (path, body, extra = {}) => req(base, route(), {
      method: 'POST',
      headers: merged({ Origin: new URL(base).origin, 'Sec-Fetch-Site': 'same-origin', 'Content-Type': 'text/plain', 'Document-URL': new URL(path, base).href, ...extra }),
      body,
    }),
    saveRaw: (href, body, extra = {}) => req(base, route(), {
      method: 'POST',
      headers: merged({ Origin: new URL(base).origin, 'Sec-Fetch-Site': 'same-origin', 'Content-Type': 'text/plain', 'Document-URL': href, ...extra }),
      body,
    }),
    saveTo: (path, body, extra = {}) => req(base, path, {
      method: 'POST',
      headers: merged({ Origin: new URL(base).origin, 'Sec-Fetch-Site': 'same-origin', 'Content-Type': 'text/plain', 'Document-URL': new URL(doc, base).href, ...extra }),
      body,
    }),
  };
}
